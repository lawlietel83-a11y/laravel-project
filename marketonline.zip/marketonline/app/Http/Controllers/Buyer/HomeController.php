<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $categories    = Category::where('is_active', true)->limit(8)->get();
        $featuredProducts = Product::active()->inStock()->with(['seller','category'])
            ->latest()->limit(12)->get();
        $categories_with_products = Category::with(['products' => fn($q) =>
            $q->active()->inStock()->limit(4)
        ])->where('is_active', true)->limit(6)->get();

        return view('buyer.home', compact('categories', 'featuredProducts', 'categories_with_products'));
    }

    public function search(Request $request)
    {
        $query = Product::active()->inStock()->with(['seller','category']);

        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function ($sq) use ($q) {
                $sq->where('name', 'like', "%$q%")
                   ->orWhere('description', 'like', "%$q%");
            });
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->filled('min_price')) {
            $query->where('price', '>=', $request->min_price);
        }
        if ($request->filled('max_price')) {
            $query->where('price', '<=', $request->max_price);
        }

        $sort = $request->get('sort', 'latest');
        match ($sort) {
            'price_asc'  => $query->orderBy('price', 'asc'),
            'price_desc' => $query->orderBy('price', 'desc'),
            'popular'    => $query->withCount('orderItems')->orderByDesc('order_items_count'),
            default      => $query->latest(),
        };

        $products   = $query->paginate(16)->withQueryString();
        $categories = Category::where('is_active', true)->get();
        return view('buyer.products.search', compact('products', 'categories'));
    }

    public function productDetail(Product $product)
    {
        if (!$product->is_active) abort(404);
        $product->load(['seller.shopProfile','category','reviews.user']);
        $related = Product::active()->inStock()
            ->where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->limit(6)->get();
        return view('buyer.products.detail', compact('product', 'related'));
    }
}

<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Shipment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TrackingController extends Controller
{
    public function index()
    {
        return view('buyer.tracking.index');
    }

    public function track(Request $request)
    {
        $request->validate([
            'order_number' => 'required|string',
        ]);

        $order = Order::with(['shipment.histories', 'items.product', 'seller'])
            ->where('order_number', $request->order_number)
            ->where('buyer_id', Auth::id())
            ->first();

        if (!$order) {
            return back()->with('error', 'Nomor pesanan tidak ditemukan.');
        }

        return view('buyer.tracking.result', compact('order'));
    }

    public function show(Order $order)
    {
        if ($order->buyer_id !== Auth::id()) abort(403);

        $order->load(['shipment.histories', 'items.product', 'seller.shopProfile', 'payment']);

        return view('buyer.tracking.show', compact('order'));
    }
}

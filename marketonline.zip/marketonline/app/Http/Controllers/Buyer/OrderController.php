<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $query = Order::with(['seller','items'])
            ->where('buyer_id', Auth::id());

        if ($request->filled('status')) $query->where('status', $request->status);

        $orders = $query->latest()->paginate(10)->withQueryString();
        return view('buyer.orders.index', compact('orders'));
    }

    public function show(Order $order)
    {
        if ($order->buyer_id !== Auth::id()) abort(403);
        $order->load(['seller.shopProfile','items.product','shipment.histories','payment']);
        return view('buyer.orders.show', compact('order'));
    }

    public function checkout(Request $request)
    {
        $cartItems = Cart::with(['product.seller'])
            ->where('user_id', Auth::id())->get();

        if ($cartItems->isEmpty()) {
            return redirect()->route('buyer.cart')->with('error', 'Keranjang kosong.');
        }

        $user = Auth::user();
        return view('buyer.orders.checkout', compact('cartItems', 'user'));
    }

    public function placeOrder(Request $request)
    {
        $request->validate([
            'shipping_name'        => 'required|string|max:255',
            'shipping_phone'       => 'required|string|max:20',
            'shipping_address'     => 'required|string',
            'shipping_city'        => 'required|string|max:100',
            'shipping_province'    => 'required|string|max:100',
            'shipping_postal_code' => 'required|string|max:10',
            'shipping_courier'     => 'required|string|max:50',
            'notes'                => 'nullable|string|max:500',
        ]);

        $cartItems = Cart::with(['product.seller'])
            ->where('user_id', Auth::id())->get();

        if ($cartItems->isEmpty()) {
            return redirect()->route('buyer.cart')->with('error', 'Keranjang kosong.');
        }

        // Validate stock
        foreach ($cartItems as $item) {
            if ($item->quantity > $item->product->stock) {
                return back()->with('error', "Stok {$item->product->name} tidak mencukupi.");
            }
        }

        DB::beginTransaction();
        try {
            // Group cart items by seller
            $bySeller = $cartItems->groupBy('product.seller_id');

            foreach ($bySeller as $sellerId => $items) {
                $subtotal  = $items->sum(fn($i) => $i->product->price * $i->quantity);
                $shipping  = 15000; // flat rate demo
                $total     = $subtotal + $shipping;

                $order = Order::create([
                    'order_number'         => Order::generateOrderNumber(),
                    'buyer_id'             => Auth::id(),
                    'seller_id'            => $sellerId,
                    'status'               => 'pending',
                    'subtotal'             => $subtotal,
                    'shipping_cost'        => $shipping,
                    'tax'                  => 0,
                    'discount'             => 0,
                    'total'                => $total,
                    'payment_status'       => 'unpaid',
                    'notes'                => $request->notes,
                    'shipping_name'        => $request->shipping_name,
                    'shipping_phone'       => $request->shipping_phone,
                    'shipping_address'     => $request->shipping_address,
                    'shipping_city'        => $request->shipping_city,
                    'shipping_province'    => $request->shipping_province,
                    'shipping_postal_code' => $request->shipping_postal_code,
                    'shipping_courier'     => $request->shipping_courier,
                ]);

                foreach ($items as $item) {
                    OrderItem::create([
                        'order_id'      => $order->id,
                        'product_id'    => $item->product_id,
                        'product_name'  => $item->product->name,
                        'product_image' => $item->product->image,
                        'price'         => $item->product->price,
                        'quantity'      => $item->quantity,
                        'subtotal'      => $item->product->price * $item->quantity,
                    ]);

                    // Deduct stock
                    $item->product->decrement('stock', $item->quantity);
                }

                Payment::create([
                    'order_id'           => $order->id,
                    'amount'             => $total,
                    'transaction_status' => 'pending',
                    'currency'           => 'IDR',
                ]);
            }

            // Clear cart
            Cart::where('user_id', Auth::id())->delete();

            DB::commit();
            return redirect()->route('buyer.orders.index')
                ->with('success', 'Pesanan berhasil dibuat! Silakan lakukan pembayaran.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function confirmReceived(Order $order)
    {
        if ($order->buyer_id !== Auth::id()) abort(403);
        if ($order->status !== 'shipped' && $order->status !== 'delivered') {
            return back()->with('error', 'Status pesanan tidak valid.');
        }

        $order->update([
            'status'       => 'completed',
            'delivered_at' => now(),
        ]);

        return back()->with('success', 'Pesanan dikonfirmasi diterima. Terima kasih!');
    }

    public function cancel(Request $request, Order $order)
    {
        if ($order->buyer_id !== Auth::id()) abort(403);
        if (!in_array($order->status, ['pending'])) {
            return back()->with('error', 'Pesanan tidak dapat dibatalkan.');
        }

        $request->validate(['cancel_reason' => 'required|string|max:500']);

        // Restore stock
        foreach ($order->items as $item) {
            if ($item->product) {
                $item->product->increment('stock', $item->quantity);
            }
        }

        $order->update([
            'status'        => 'cancelled',
            'cancelled_at'  => now(),
            'cancel_reason' => $request->cancel_reason,
        ]);

        return back()->with('success', 'Pesanan berhasil dibatalkan.');
    }
}

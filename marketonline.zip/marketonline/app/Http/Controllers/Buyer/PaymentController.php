<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{
    public function show(Order $order)
    {
        if ($order->buyer_id !== Auth::id()) abort(403);

        $order->load(['items.product', 'payment', 'seller']);

        return view('buyer.orders.payment', compact('order'));
    }

    /**
     * Simulate payment confirmation (demo — in production use Midtrans callback)
     */
    public function confirm(Request $request, Order $order)
    {
        if ($order->buyer_id !== Auth::id()) abort(403);

        if ($order->payment_status === 'paid') {
            return back()->with('error', 'Pesanan ini sudah dibayar.');
        }

        $request->validate([
            'payment_method' => 'required|in:transfer_bank,virtual_account,qris,cod',
        ]);

        // Update order
        $order->update([
            'status'         => 'paid',
            'payment_status' => 'paid',
            'payment_method' => $request->payment_method,
            'paid_at'        => now(),
        ]);

        // Update or create payment record
        Payment::updateOrCreate(
            ['order_id' => $order->id],
            [
                'payment_method'     => $request->payment_method,
                'payment_channel'    => $request->payment_method,
                'transaction_status' => 'success',
                'amount'             => $order->total,
                'currency'           => 'IDR',
                'paid_at'            => now(),
            ]
        );

        return redirect()->route('buyer.orders.show', $order)
            ->with('success', 'Pembayaran berhasil dikonfirmasi! Pesanan Anda sedang diproses.');
    }

    /**
     * Midtrans notification webhook (production)
     */
    public function notification(Request $request)
    {
        $payload = $request->all();

        $order = Order::where('order_number', $payload['order_id'] ?? '')->first();
        if (!$order) return response()->json(['message' => 'Order not found'], 404);

        $transactionStatus = $payload['transaction_status'] ?? '';
        $fraudStatus       = $payload['fraud_status'] ?? '';

        if ($transactionStatus === 'capture' && $fraudStatus === 'accept') {
            $status = 'paid';
        } elseif ($transactionStatus === 'settlement') {
            $status = 'paid';
        } elseif (in_array($transactionStatus, ['cancel', 'deny', 'expire'])) {
            $status = 'cancelled';
        } elseif ($transactionStatus === 'pending') {
            $status = 'pending';
        } else {
            $status = 'pending';
        }

        if ($status === 'paid') {
            $order->update([
                'status'         => 'paid',
                'payment_status' => 'paid',
                'paid_at'        => now(),
            ]);
            Payment::updateOrCreate(['order_id' => $order->id], [
                'transaction_id'     => $payload['transaction_id'] ?? null,
                'payment_method'     => $payload['payment_type'] ?? null,
                'transaction_status' => 'success',
                'amount'             => $payload['gross_amount'] ?? $order->total,
                'raw_response'       => $payload,
                'paid_at'            => now(),
            ]);
        }

        return response()->json(['message' => 'OK']);
    }
}

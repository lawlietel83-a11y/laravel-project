<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Shipment;
use App\Models\ShipmentHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $query = Order::with(['buyer','items.product'])
            ->where('seller_id', Auth::id());

        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('search')) {
            $query->where('order_number', 'like', "%{$request->search}%");
        }

        $orders = $query->latest()->paginate(15)->withQueryString();
        return view('seller.orders.index', compact('orders'));
    }

    public function show(Order $order)
    {
        if ($order->seller_id !== Auth::id()) abort(403);
        $order->load(['buyer','items.product','shipment.histories','payment']);
        return view('seller.orders.show', compact('order'));
    }

    public function process(Order $order)
    {
        if ($order->seller_id !== Auth::id()) abort(403);
        if ($order->status !== 'paid') {
            return back()->with('error', 'Hanya pesanan yang sudah dibayar yang bisa diproses.');
        }
        $order->update(['status' => 'processing']);
        return back()->with('success', 'Pesanan sedang diproses.');
    }

    public function ship(Request $request, Order $order)
    {
        if ($order->seller_id !== Auth::id()) abort(403);

        $request->validate([
            'tracking_number' => 'required|string|max:100',
            'courier'         => 'required|string|max:50',
            'service'         => 'nullable|string|max:100',
        ]);

        $order->update([
            'status'          => 'shipped',
            'tracking_number' => $request->tracking_number,
            'shipping_courier'=> $request->courier,
            'shipping_service'=> $request->service,
            'shipped_at'      => now(),
        ]);

        $shipment = Shipment::updateOrCreate(
            ['order_id' => $order->id],
            [
                'courier'          => $request->courier,
                'service'          => $request->service,
                'tracking_number'  => $request->tracking_number,
                'status'           => 'in_transit',
                'origin_city'      => $order->seller->shopProfile?->city ?? '',
                'destination_city' => $order->shipping_city,
                'shipped_at'       => now(),
            ]
        );

        ShipmentHistory::create([
            'shipment_id' => $shipment->id,
            'status'      => 'in_transit',
            'description' => 'Paket telah dikirim oleh seller.',
            'location'    => $order->seller->shopProfile?->city ?? 'Gudang Seller',
            'occurred_at' => now(),
        ]);

        return back()->with('success', 'Pesanan berhasil dikirim.');
    }
}

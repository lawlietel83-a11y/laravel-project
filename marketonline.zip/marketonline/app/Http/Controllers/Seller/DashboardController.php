<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $seller = Auth::user();

        $stats = [
            'total_products' => Product::where('seller_id', $seller->id)->count(),
            'active_products'=> Product::where('seller_id', $seller->id)->where('is_active', true)->count(),
            'total_orders'   => Order::where('seller_id', $seller->id)->count(),
            'pending_orders' => Order::where('seller_id', $seller->id)->where('status', 'pending')->count(),
            'processing_orders' => Order::where('seller_id', $seller->id)->where('status', 'processing')->count(),
            'total_revenue'  => Order::where('seller_id', $seller->id)
                                     ->whereIn('status', ['completed','delivered'])
                                     ->sum('total'),
        ];

        $recentOrders = Order::with(['buyer','items'])
            ->where('seller_id', $seller->id)
            ->latest()->limit(8)->get();

        $lowStockProducts = Product::where('seller_id', $seller->id)
            ->where('stock', '<=', 5)
            ->where('is_active', true)
            ->get();

        return view('seller.dashboard.index', compact('stats', 'recentOrders', 'lowStockProducts'));
    }
}

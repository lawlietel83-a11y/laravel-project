<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Models\Category;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_users'    => User::count(),
            'total_sellers'  => User::role('seller')->count(),
            'total_buyers'   => User::role('buyer')->count(),
            'total_products' => Product::count(),
            'total_orders'   => Order::count(),
            'total_revenue'  => Order::whereIn('status', ['completed','delivered'])->sum('total'),
            'pending_orders' => Order::where('status', 'pending')->count(),
            'total_categories' => Category::count(),
        ];

        $recentOrders = Order::with(['buyer','seller','items'])
            ->latest()->limit(10)->get();

        $topProducts = Product::withCount('orderItems')
            ->orderByDesc('order_items_count')
            ->limit(5)->get();

        return view('admin.dashboard.index', compact('stats', 'recentOrders', 'topProducts'));
    }
}

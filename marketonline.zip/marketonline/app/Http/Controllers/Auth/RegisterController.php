<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\ShopProfile;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class RegisterController extends Controller
{
    public function showRegistrationForm()
    {
        if (Auth::check()) return redirect()->route('buyer.home');
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $request->validate([
            'name'      => 'required|string|max:255',
            'email'     => 'required|email|unique:users,email',
            'password'  => 'required|string|min:8|confirmed',
            'role'      => 'required|in:buyer,seller',
            'phone'     => 'nullable|string|max:20',
            'shop_name' => 'required_if:role,seller|string|max:255',
        ]);

        $user = User::create([
            'name'      => $request->name,
            'email'     => $request->email,
            'password'  => Hash::make($request->password),
            'phone'     => $request->phone,
            'is_active' => true,
        ]);

        $user->assignRole($request->role);

        if ($request->role === 'seller') {
            ShopProfile::create([
                'seller_id'  => $user->id,
                'shop_name'  => $request->shop_name,
                'slug'       => Str::slug($request->shop_name) . '-' . $user->id,
                'is_verified'=> false,
            ]);
        }

        Auth::login($user);
        $request->session()->regenerate();

        if ($request->role === 'seller') {
            return redirect()->route('seller.dashboard')->with('success', 'Akun seller berhasil dibuat!');
        }
        return redirect()->route('buyer.home')->with('success', 'Akun berhasil dibuat!');
    }
}

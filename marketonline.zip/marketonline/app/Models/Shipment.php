<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shipment extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'courier',
        'service',
        'tracking_number',
        'status',
        'origin_city',
        'destination_city',
        'weight',
        'cost',
        'estimated_days',
        'shipped_at',
        'delivered_at',
        'raw_tracking',
    ];

    protected $casts = [
        'cost'        => 'decimal:2',
        'shipped_at'  => 'datetime',
        'delivered_at'=> 'datetime',
        'raw_tracking'=> 'array',
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function histories()
    {
        return $this->hasMany(ShipmentHistory::class)->orderByDesc('occurred_at');
    }

    public function getStatusLabelAttribute()
    {
        $labels = [
            'pending'   => ['label' => 'Menunggu Pickup',  'class' => 'secondary'],
            'picked_up' => ['label' => 'Sudah Diambil',    'class' => 'info'],
            'in_transit'=> ['label' => 'Dalam Perjalanan', 'class' => 'primary'],
            'out_for_delivery' => ['label' => 'Sedang Diantar', 'class' => 'warning'],
            'delivered' => ['label' => 'Terkirim',         'class' => 'success'],
            'failed'    => ['label' => 'Gagal Kirim',      'class' => 'danger'],
            'returned'  => ['label' => 'Dikembalikan',     'class' => 'danger'],
        ];
        return $labels[$this->status] ?? ['label' => $this->status, 'class' => 'secondary'];
    }
}

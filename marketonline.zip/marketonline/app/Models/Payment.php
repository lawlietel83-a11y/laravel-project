<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    const STATUS_PENDING  = 'pending';
    const STATUS_SUCCESS  = 'success';
    const STATUS_FAILED   = 'failed';
    const STATUS_EXPIRED  = 'expired';
    const STATUS_REFUNDED = 'refunded';

    protected $fillable = [
        'order_id',
        'payment_method',
        'payment_channel',
        'transaction_id',
        'transaction_status',
        'amount',
        'currency',
        'snap_token',
        'redirect_url',
        'raw_response',
        'paid_at',
        'expired_at',
    ];

    protected $casts = [
        'amount'       => 'decimal:2',
        'raw_response' => 'array',
        'paid_at'      => 'datetime',
        'expired_at'   => 'datetime',
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function getFormattedAmountAttribute()
    {
        return 'Rp ' . number_format($this->amount, 0, ',', '.');
    }

    public function getStatusLabelAttribute()
    {
        $labels = [
            'pending'  => ['label' => 'Menunggu Pembayaran', 'class' => 'warning'],
            'success'  => ['label' => 'Berhasil',           'class' => 'success'],
            'failed'   => ['label' => 'Gagal',              'class' => 'danger'],
            'expired'  => ['label' => 'Kedaluwarsa',        'class' => 'secondary'],
            'refunded' => ['label' => 'Dikembalikan',       'class' => 'info'],
        ];
        return $labels[$this->transaction_status] ?? ['label' => $this->transaction_status, 'class' => 'secondary'];
    }
}

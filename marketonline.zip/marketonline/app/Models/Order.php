<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    const STATUS_PENDING = 'pending';
    const STATUS_PAID = 'paid';
    const STATUS_PROCESSING = 'processing';
    const STATUS_SHIPPED = 'shipped';
    const STATUS_DELIVERED = 'delivered';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_REFUNDED = 'refunded';

    protected $fillable = [
        'order_number',
        'buyer_id',
        'seller_id',
        'status',
        'subtotal',
        'shipping_cost',
        'tax',
        'discount',
        'total',
        'payment_method',
        'payment_status',
        'payment_token',
        'payment_url',
        'paid_at',
        'notes',
        'shipping_name',
        'shipping_phone',
        'shipping_address',
        'shipping_city',
        'shipping_province',
        'shipping_postal_code',
        'shipping_courier',
        'shipping_service',
        'tracking_number',
        'shipped_at',
        'delivered_at',
        'cancelled_at',
        'cancel_reason',
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'shipping_cost' => 'decimal:2',
        'tax' => 'decimal:2',
        'discount' => 'decimal:2',
        'total' => 'decimal:2',
        'paid_at' => 'datetime',
        'shipped_at' => 'datetime',
        'delivered_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    public function buyer()
    {
        return $this->belongsTo(User::class, 'buyer_id');
    }

    public function seller()
    {
        return $this->belongsTo(User::class, 'seller_id');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function shipment()
    {
        return $this->hasOne(Shipment::class);
    }

    public function payment()
    {
        return $this->hasOne(Payment::class);
    }

    public function getStatusLabelAttribute()
    {
        $labels = [
            'pending'    => ['label' => 'Menunggu Pembayaran', 'class' => 'warning'],
            'paid'       => ['label' => 'Pembayaran Dikonfirmasi', 'class' => 'info'],
            'processing' => ['label' => 'Sedang Diproses', 'class' => 'primary'],
            'shipped'    => ['label' => 'Sedang Dikirim', 'class' => 'info'],
            'delivered'  => ['label' => 'Terkirim', 'class' => 'success'],
            'completed'  => ['label' => 'Selesai', 'class' => 'success'],
            'cancelled'  => ['label' => 'Dibatalkan', 'class' => 'danger'],
            'refunded'   => ['label' => 'Dikembalikan', 'class' => 'secondary'],
        ];
        return $labels[$this->status] ?? ['label' => $this->status, 'class' => 'secondary'];
    }

    public function getFormattedTotalAttribute()
    {
        return 'Rp ' . number_format($this->total, 0, ',', '.');
    }

    public static function generateOrderNumber()
    {
        return 'MO-' . date('Ymd') . '-' . strtoupper(uniqid());
    }

    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }
}

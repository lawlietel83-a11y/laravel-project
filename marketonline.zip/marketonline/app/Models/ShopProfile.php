<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShopProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'seller_id',
        'shop_name',
        'slug',
        'description',
        'logo',
        'banner',
        'city',
        'province',
        'address',
        'phone',
        'is_verified',
        'rating',
        'total_sales',
    ];

    protected $casts = [
        'is_verified' => 'boolean',
        'rating'      => 'decimal:2',
    ];

    public function seller()
    {
        return $this->belongsTo(User::class, 'seller_id');
    }

    public function getLogoUrlAttribute()
    {
        return $this->logo ? asset('storage/' . $this->logo) : asset('images/default-shop.png');
    }

    public function getBannerUrlAttribute()
    {
        return $this->banner ? asset('storage/' . $this->banner) : asset('images/default-banner.png');
    }
}

# MarketOnline – Sistem Marketplace Laravel 12

Sistem marketplace online lengkap dibangun dengan **Laravel 12**, mendukung 3 role: **Admin**, **Seller**, dan **Buyer**.

---

## 🚀 Fitur Utama

| Fitur | Admin | Seller | Buyer |
|---|---|---|---|
| Dashboard statistik | ✅ | ✅ | - |
| CRUD Produk | ✅ (kelola semua) | ✅ (produk sendiri) | - |
| CRUD Kategori | ✅ | - | - |
| CRUD Pengguna | ✅ | - | - |
| Manajemen Pesanan | ✅ | ✅ | ✅ |
| Keranjang Belanja | - | - | ✅ |
| Checkout | - | - | ✅ |
| Pembayaran | - | - | ✅ |
| Tracking Pengiriman | ✅ | ✅ | ✅ |
| Input Nomor Resi | - | ✅ | - |
| Konfirmasi Terima | - | - | ✅ |
| Review Produk | - | - | ✅ |

---

## 📋 Persyaratan Sistem

- PHP >= 8.2
- Composer >= 2.x
- MySQL >= 8.0
- Node.js >= 18 (opsional, untuk asset)
- Laravel 12.x

---

## ⚙️ Instalasi

### 1. Clone / Extract Proyek

```bash
# Jika dari ZIP, extract ke folder pilihan Anda
unzip marketonline.zip -d marketonline
cd marketonline
```

### 2. Install Dependensi PHP

```bash
composer install
```

### 3. Konfigurasi Environment

```bash
cp .env.example .env
php artisan key:generate
```

Edit file `.env`, sesuaikan konfigurasi database:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=marketonline
DB_USERNAME=root
DB_PASSWORD=your_password
```

### 4. Buat Database

Buat database MySQL bernama `marketonline`:

```sql
CREATE DATABASE marketonline CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 5. Jalankan Migrasi & Seeder

```bash
php artisan migrate --seed
```

Perintah ini akan:
- Membuat semua tabel database
- Membuat roles & permissions (Admin, Seller, Buyer)
- Membuat 3 akun demo (admin, seller, buyer)
- Membuat 8 kategori produk
- Membuat 5 produk contoh

### 6. Buat Storage Link

```bash
php artisan storage:link
```

### 7. Jalankan Server

```bash
php artisan serve
```

Buka browser: **http://localhost:8000**

---

## 👤 Akun Demo

| Role | Email | Password |
|---|---|---|
| **Admin** | admin@marketonline.com | password |
| **Seller** | seller@marketonline.com | password |
| **Buyer** | buyer@marketonline.com | password |

---

## 🗂️ Struktur Folder Utama

```
marketonline/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── Admin/          # DashboardController, UserController, CategoryController, OrderController, ProductController
│   │   │   ├── Auth/           # LoginController, RegisterController
│   │   │   ├── Buyer/          # HomeController, CartController, OrderController, PaymentController, TrackingController
│   │   │   └── Seller/         # DashboardController, ProductController, OrderController
│   │   └── Middleware/
│   │       └── CheckRole.php   # Middleware cek role user
│   ├── Models/
│   │   ├── User.php            # Model pengguna (HasRoles)
│   │   ├── Product.php         # Model produk
│   │   ├── Category.php        # Model kategori
│   │   ├── Order.php           # Model pesanan
│   │   ├── OrderItem.php       # Model item pesanan
│   │   ├── Cart.php            # Model keranjang
│   │   ├── Payment.php         # Model pembayaran
│   │   ├── Shipment.php        # Model pengiriman
│   │   ├── ShipmentHistory.php # Model histori pengiriman
│   │   ├── Review.php          # Model ulasan
│   │   └── ShopProfile.php     # Model profil toko seller
│   └── Providers/
│       └── AppServiceProvider.php
├── database/
│   ├── migrations/             # 13 file migrasi lengkap
│   ├── seeders/                # DatabaseSeeder, RolePermissionSeeder, UserSeeder, CategorySeeder, ProductSeeder
│   └── factories/
│       └── UserFactory.php
├── resources/
│   └── views/
│       ├── layouts/            # app.blade.php, admin.blade.php, seller.blade.php
│       ├── auth/               # login.blade.php, register.blade.php
│       ├── buyer/              # home, produk, cart, orders, tracking, payment
│       ├── seller/             # dashboard, products (CRUD), orders
│       ├── admin/              # dashboard, users (CRUD), categories (CRUD), products, orders
│       └── errors/             # 403, 404, 500
├── routes/
│   ├── web.php                 # Semua route web (buyer, seller, admin)
│   ├── api.php
│   └── console.php
├── config/
│   ├── app.php, auth.php, database.php, cache.php, session.php
│   ├── permission.php          # Config Spatie Permission
│   ├── payment.php             # Config Midtrans & RajaOngkir
│   └── ...
├── bootstrap/
│   ├── app.php                 # Bootstrap Laravel 12
│   └── providers.php
├── public/
│   ├── index.php
│   └── .htaccess
├── artisan                     # Laravel artisan CLI
├── composer.json
└── .env.example
```

---

## 🔄 Alur Sistem

### Alur Pembeli (Buyer)
1. Register / Login sebagai Buyer
2. Browse produk di halaman utama atau cari produk
3. Klik produk → lihat detail → tambah ke keranjang
4. Ke halaman keranjang → checkout
5. Isi alamat pengiriman & pilih kurir
6. Buat pesanan → pilih metode bayar → konfirmasi pembayaran
7. Pantau status pesanan di "Pesanan Saya"
8. Lacak pengiriman via "Tracking Pesanan"
9. Klik "Pesanan Diterima" setelah barang tiba

### Alur Seller
1. Register / Login sebagai Seller
2. Dashboard menampilkan statistik toko
3. Tambah/edit/hapus produk
4. Lihat pesanan masuk → proses pesanan
5. Input nomor resi → konfirmasi pengiriman

### Alur Admin
1. Login sebagai Admin
2. Dashboard statistik global
3. Kelola semua pengguna (tambah/edit/nonaktif/hapus)
4. Kelola kategori produk
5. Monitor & kelola semua produk
6. Monitor & update status semua pesanan

---

## 💳 Integrasi Pembayaran

Sistem ini menggunakan **simulasi pembayaran** untuk demo.
Untuk produksi, daftarkan akun Midtrans dan isi di `.env`:

```env
MIDTRANS_SERVER_KEY=your_server_key
MIDTRANS_CLIENT_KEY=your_client_key
MIDTRANS_IS_PRODUCTION=false
```

---

## 📦 Package yang Digunakan

- `laravel/framework` ^12.0
- `spatie/laravel-permission` ^6.0 – Manajemen Role & Permission
- `laravel/sanctum` ^4.0 – API Authentication
- `barryvdh/laravel-dompdf` ^3.0 – Generate PDF (invoice)
- `intervention/image` ^3.0 – Resize & optimasi gambar

---

## 🛠️ Perintah Berguna

```bash
# Jalankan ulang migrasi + seeder
php artisan migrate:fresh --seed

# Clear cache
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear

# Buat storage link
php artisan storage:link

# Tinker (debug interaktif)
php artisan tinker
```

---

## 📝 Catatan

- Gambar produk disimpan di `storage/app/public/products/`
- Gambar kategori disimpan di `storage/app/public/categories/`
- Avatar user disimpan di `storage/app/public/avatars/`
- Log aplikasi ada di `storage/logs/laravel.log`
- Semua harga dalam Rupiah (IDR)
- Timezone default: Asia/Jakarta

@extends('layouts.app')
@section('title','Masuk')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card mt-4">
                <div class="card-body p-5">
                    <h4 class="fw-bold text-center mb-1">Selamat Datang</h4>
                    <p class="text-center text-muted small mb-4">Masuk ke akun MarketOnline Anda</p>
                    <form action="{{ route('login') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                                   value="{{ old('email') }}" placeholder="contoh@email.com" required>
                            @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Password</label>
                            <input type="password" name="password" class="form-control @error('password') is-invalid @enderror"
                                   placeholder="Minimal 6 karakter" required>
                            @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember">
                                <label class="form-check-label small" for="remember">Ingat saya</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">Masuk</button>
                    </form>
                    <hr>
                    <p class="text-center mb-0 small">Belum punya akun?
                        <a href="{{ route('register') }}" class="text-danger fw-semibold">Daftar Sekarang</a>
                    </p>
                    <div class="mt-3 p-3 bg-light rounded small">
                        <strong>Demo Akun:</strong><br>
                        Admin: admin@marketonline.com / password<br>
                        Seller: seller@marketonline.com / password<br>
                        Buyer: buyer@marketonline.com / password
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

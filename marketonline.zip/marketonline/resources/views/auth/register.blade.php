@extends('layouts.app')
@section('title','Daftar')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-4">
                <div class="card-body p-5">
                    <h4 class="fw-bold text-center mb-1">Buat Akun Baru</h4>
                    <p class="text-center text-muted small mb-4">Bergabung dengan MarketOnline</p>
                    <form action="{{ route('register') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Daftar Sebagai</label>
                            <div class="d-flex gap-3">
                                <div class="form-check flex-fill border rounded p-3">
                                    <input class="form-check-input" type="radio" name="role" value="buyer" id="roleBuyer" checked>
                                    <label class="form-check-label w-100" for="roleBuyer">
                                        <i class="bi bi-bag me-1"></i><strong>Pembeli</strong><br>
                                        <small class="text-muted">Beli produk dari seller</small>
                                    </label>
                                </div>
                                <div class="form-check flex-fill border rounded p-3">
                                    <input class="form-check-input" type="radio" name="role" value="seller" id="roleSeller">
                                    <label class="form-check-label w-100" for="roleSeller">
                                        <i class="bi bi-shop me-1"></i><strong>Seller</strong><br>
                                        <small class="text-muted">Jual produk Anda</small>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Lengkap</label>
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                                   value="{{ old('name') }}" placeholder="Nama lengkap Anda" required>
                            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div id="shopNameGroup" class="mb-3 d-none">
                            <label class="form-label fw-semibold">Nama Toko</label>
                            <input type="text" name="shop_name" class="form-control @error('shop_name') is-invalid @enderror"
                                   value="{{ old('shop_name') }}" placeholder="Nama toko Anda">
                            @error('shop_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                                   value="{{ old('email') }}" placeholder="email@contoh.com" required>
                            @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">No. HP</label>
                            <input type="text" name="phone" class="form-control" value="{{ old('phone') }}" placeholder="08xxxxxxxxxx">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Password</label>
                            <input type="password" name="password" class="form-control @error('password') is-invalid @enderror"
                                   placeholder="Minimal 8 karakter" required>
                            @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Konfirmasi Password</label>
                            <input type="password" name="password_confirmation" class="form-control" placeholder="Ulangi password" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">Daftar Sekarang</button>
                    </form>
                    <hr>
                    <p class="text-center mb-0 small">Sudah punya akun?
                        <a href="{{ route('login') }}" class="text-danger fw-semibold">Masuk</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@push('scripts')
<script>
document.querySelectorAll('input[name="role"]').forEach(r => {
    r.addEventListener('change', function() {
        document.getElementById('shopNameGroup').classList.toggle('d-none', this.value !== 'seller');
    });
});
@if(old('role') === 'seller')
    document.getElementById('shopNameGroup').classList.remove('d-none');
@endif
</script>
@endpush
@endsection

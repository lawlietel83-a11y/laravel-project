@extends('layouts.admin')
@section('title','Dashboard')
@section('page-title','Dashboard Admin')
@section('content')
<!-- Stats -->
<div class="row g-4 mb-4">
    @foreach([
        ['label'=>'Total Pengguna', 'value'=>number_format($stats['total_users']), 'icon'=>'bi-people-fill',      'color'=>'#1565c0'],
        ['label'=>'Total Seller',   'value'=>number_format($stats['total_sellers']),'icon'=>'bi-shop-window',     'color'=>'#2e7d32'],
        ['label'=>'Total Produk',   'value'=>number_format($stats['total_products']),'icon'=>'bi-box-seam-fill',  'color'=>'#e65100'],
        ['label'=>'Total Pesanan',  'value'=>number_format($stats['total_orders']), 'icon'=>'bi-receipt-cutoff',  'color'=>'#6a1b9a'],
        ['label'=>'Menunggu',       'value'=>number_format($stats['pending_orders']),'icon'=>'bi-hourglass-split','color'=>'#f57f17'],
        ['label'=>'Total Pendapatan','value'=>'Rp '.number_format($stats['total_revenue'],0,',','.'), 'icon'=>'bi-cash-stack','color'=>'#c62828'],
    ] as $s)
    <div class="col-6 col-md-4 col-lg-2">
        <div class="card stat-card p-3 h-100" style="border-left-color:{{ $s['color'] }}!important">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <span class="small text-muted">{{ $s['label'] }}</span>
                <i class="bi {{ $s['icon'] }}" style="color:{{ $s['color'] }};font-size:1.3rem"></i>
            </div>
            <h4 class="fw-bold mb-0" style="color:{{ $s['color'] }}">{{ $s['value'] }}</h4>
        </div>
    </div>
    @endforeach
</div>

<div class="row g-4">
    <!-- Recent Orders -->
    <div class="col-md-8">
        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold mb-0">Pesanan Terbaru</h6>
                <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-primary btn-sm">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr><th>No. Pesanan</th><th>Pembeli</th><th>Total</th><th>Status</th><th>Tanggal</th></tr>
                    </thead>
                    <tbody>
                        @forelse($recentOrders as $order)
                        <tr>
                            <td><a href="{{ route('admin.orders.show',$order) }}" class="fw-semibold text-decoration-none">
                                #{{ $order->order_number }}</a></td>
                            <td>{{ $order->buyer->name }}</td>
                            <td>{{ $order->formatted_total }}</td>
                            <td><span class="badge bg-{{ $order->status_label['class'] }}">{{ $order->status_label['label'] }}</span></td>
                            <td class="text-muted small">{{ $order->created_at->format('d M Y') }}</td>
                        </tr>
                        @empty
                        <tr><td colspan="5" class="text-center text-muted py-4">Belum ada pesanan.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Top Products -->
    <div class="col-md-4">
        <div class="card p-4">
            <h6 class="fw-bold mb-3">Produk Terlaris</h6>
            @forelse($topProducts as $i => $product)
            <div class="d-flex align-items-center gap-3 mb-3">
                <div class="rounded-circle d-flex align-items-center justify-content-center text-white fw-bold"
                     style="width:32px;height:32px;background:#e53935;flex-shrink:0;font-size:.8rem">{{ $i+1 }}</div>
                <div class="flex-grow-1">
                    <div class="small fw-semibold">{{ Str::limit($product->name,28) }}</div>
                    <div class="text-muted" style="font-size:.75rem">{{ $product->order_items_count }} terjual</div>
                </div>
                <div class="fw-semibold small text-danger">{{ $product->formatted_price }}</div>
            </div>
            @empty
            <p class="text-muted small text-center">Belum ada data.</p>
            @endforelse
        </div>

        <div class="card p-4 mt-4">
            <h6 class="fw-bold mb-3">Aksi Cepat</h6>
            <div class="d-grid gap-2">
                <a href="{{ route('admin.users.create') }}" class="btn btn-outline-primary btn-sm">
                    <i class="bi bi-person-plus me-2"></i>Tambah User
                </a>
                <a href="{{ route('admin.categories.create') }}" class="btn btn-outline-success btn-sm">
                    <i class="bi bi-tag me-2"></i>Tambah Kategori
                </a>
                <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-warning btn-sm">
                    <i class="bi bi-receipt me-2"></i>Kelola Pesanan
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

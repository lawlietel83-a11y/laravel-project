@extends('layouts.admin')
@section('title','Kategori')
@section('page-title','Manajemen Kategori')
@section('content')
<div class="card p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0">Daftar Kategori</h6>
        <a href="{{ route('admin.categories.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-2"></i>Tambah Kategori
        </a>
    </div>
    <form class="row g-2 mb-4" method="GET">
        <div class="col-md-6">
            <input type="text" name="search" class="form-control form-control-sm"
                   placeholder="Cari kategori…" value="{{ request('search') }}">
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary btn-sm">Cari</button>
            <a href="{{ route('admin.categories.index') }}" class="btn btn-outline-secondary btn-sm ms-1">Reset</a>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr><th>#</th><th>Gambar</th><th>Nama</th><th>Slug</th><th>Produk</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
                @forelse($categories as $cat)
                <tr>
                    <td>{{ $loop->iteration + ($categories->currentPage()-1)*$categories->perPage() }}</td>
                    <td>
                        <img src="{{ $cat->image_url }}" width="44" height="44"
                             class="rounded" style="object-fit:cover">
                    </td>
                    <td class="fw-semibold">{{ $cat->name }}</td>
                    <td class="text-muted small">{{ $cat->slug }}</td>
                    <td><span class="badge bg-info text-dark">{{ $cat->products_count }}</span></td>
                    <td><span class="badge {{ $cat->is_active ? 'bg-success':'bg-secondary' }}">
                        {{ $cat->is_active ? 'Aktif':'Nonaktif' }}</span></td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="{{ route('admin.categories.edit',$cat) }}" class="btn btn-outline-warning btn-sm">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="{{ route('admin.categories.destroy',$cat) }}" method="POST"
                                  onsubmit="return confirm('Hapus kategori {{ $cat->name }}?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center py-5 text-muted">Belum ada kategori.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $categories->links() }}
</div>
@endsection

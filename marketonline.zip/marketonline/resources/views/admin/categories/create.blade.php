@extends('layouts.admin')
@section('title', isset($category) ? 'Edit Kategori' : 'Tambah Kategori')
@section('page-title', isset($category) ? 'Edit Kategori' : 'Tambah Kategori')
@section('content')
<div class="row justify-content-center">
    <div class="col-md-7">
        <div class="card p-5">
            <h5 class="fw-bold mb-4">{{ isset($category) ? 'Edit Kategori' : 'Tambah Kategori Baru' }}</h5>
            <form action="{{ isset($category) ? route('admin.categories.update',$category) : route('admin.categories.store') }}"
                  method="POST" enctype="multipart/form-data">
                @csrf
                @if(isset($category)) @method('PUT') @endif

                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Kategori</label>
                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                           value="{{ old('name', $category->name ?? '') }}" required placeholder="Contoh: Elektronik">
                    @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Kategori Induk (opsional)</label>
                    <select name="parent_id" class="form-select">
                        <option value="">-- Tidak Ada Induk --</option>
                        @foreach($parents as $parent)
                        <option value="{{ $parent->id }}"
                            {{ old('parent_id', $category->parent_id ?? '') == $parent->id ? 'selected':'' }}>
                            {{ $parent->name }}
                        </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Deskripsi</label>
                    <textarea name="description" rows="3" class="form-control"
                              placeholder="Deskripsi singkat kategori">{{ old('description', $category->description ?? '') }}</textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Gambar Kategori</label>
                    @if(isset($category) && $category->image)
                    <div class="mb-2">
                        <img src="{{ $category->image_url }}" height="80" class="rounded border" alt="">
                        <small class="text-muted d-block mt-1">Gambar saat ini. Upload baru untuk mengganti.</small>
                    </div>
                    @endif
                    <input type="file" name="image" class="form-control @error('image') is-invalid @enderror"
                           accept="image/jpg,image/jpeg,image/png,image/webp">
                    @error('image')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>

                <div class="mb-4">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="isActive"
                               {{ old('is_active', $category->is_active ?? true) ? 'checked':'' }}>
                        <label class="form-check-label fw-semibold" for="isActive">Kategori Aktif</label>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary px-5">
                        <i class="bi bi-check-lg me-2"></i>{{ isset($category) ? 'Simpan' : 'Tambah' }}
                    </button>
                    <a href="{{ route('admin.categories.index') }}" class="btn btn-outline-secondary px-4">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@extends('layouts.admin')
@section('title','Detail Pesanan')
@section('page-title','Detail Pesanan')
@section('content')
<div class="row g-4">
    <div class="col-md-8">
        <div class="card p-4 mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0">#{{ $order->order_number }}</h5>
                <span class="badge bg-{{ $order->status_label['class'] }} fs-6">{{ $order->status_label['label'] }}</span>
            </div>
            <div class="row g-3 small text-muted mb-3">
                <div class="col-md-4"><strong>Pembeli:</strong> {{ $order->buyer->name }}</div>
                <div class="col-md-4"><strong>Seller:</strong> {{ $order->seller->name }}</div>
                <div class="col-md-4"><strong>Tanggal:</strong> {{ $order->created_at->format('d M Y H:i') }}</div>
                @if($order->paid_at)
                <div class="col-md-4"><strong>Dibayar:</strong> {{ $order->paid_at->format('d M Y H:i') }}</div>
                @endif
                @if($order->tracking_number)
                <div class="col-md-4"><strong>Resi:</strong> {{ $order->tracking_number }}</div>
                @endif
            </div>

            <h6 class="fw-bold mb-3 border-top pt-3">Produk Dipesan</h6>
            @foreach($order->items as $item)
            <div class="d-flex gap-3 align-items-center border-bottom pb-2 mb-2">
                <img src="{{ $item->product_image ? asset('storage/'.$item->product_image) : asset('images/default-product.png') }}"
                     width="50" height="50" class="rounded" style="object-fit:cover">
                <div class="flex-grow-1 small">
                    <div class="fw-semibold">{{ $item->product_name }}</div>
                    <div class="text-muted">{{ $item->quantity }} x {{ $item->formatted_price }}</div>
                </div>
                <div class="fw-bold text-danger small">{{ $item->formatted_subtotal }}</div>
            </div>
            @endforeach

            <div class="border-top pt-3 mt-2">
                <div class="d-flex justify-content-between small mb-1">
                    <span class="text-muted">Subtotal</span><span>Rp {{ number_format($order->subtotal,0,',','.') }}</span>
                </div>
                <div class="d-flex justify-content-between small mb-1">
                    <span class="text-muted">Ongkir</span><span>Rp {{ number_format($order->shipping_cost,0,',','.') }}</span>
                </div>
                <div class="d-flex justify-content-between fw-bold mt-2">
                    <span>Total</span><span class="text-danger">{{ $order->formatted_total }}</span>
                </div>
            </div>
        </div>

        @if($order->shipment && $order->shipment->histories->count())
        <div class="card p-4">
            <h6 class="fw-bold mb-3">Riwayat Pengiriman</h6>
            @foreach($order->shipment->histories as $hist)
            <div class="d-flex gap-3 mb-3 border-bottom pb-2">
                <div class="text-muted small" style="min-width:110px">{{ $hist->occurred_at->format('d M Y H:i') }}</div>
                <div>
                    <div class="fw-semibold small">{{ $hist->description }}</div>
                    @if($hist->location)<div class="text-muted small"><i class="bi bi-geo-alt me-1"></i>{{ $hist->location }}</div>@endif
                </div>
            </div>
            @endforeach
        </div>
        @endif
    </div>

    <div class="col-md-4">
        <!-- Update Status -->
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3">Update Status</h6>
            <form action="{{ route('admin.orders.update-status',$order) }}" method="POST">
                @csrf @method('PATCH')
                <div class="mb-3">
                    <select name="status" class="form-select">
                        @foreach(['pending','paid','processing','shipped','delivered','completed','cancelled','refunded'] as $s)
                        <option value="{{ $s }}" {{ $order->status===$s?'selected':'' }}>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <textarea name="cancel_reason" rows="2" class="form-control form-control-sm"
                              placeholder="Alasan (jika dibatalkan)">{{ $order->cancel_reason }}</textarea>
                </div>
                <button class="btn btn-primary btn-sm w-100">Update Status</button>
            </form>
        </div>

        <!-- Shipping Address -->
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3">Alamat Pengiriman</h6>
            <p class="fw-semibold small mb-1">{{ $order->shipping_name }}</p>
            <p class="small mb-1">{{ $order->shipping_phone }}</p>
            <p class="small text-muted mb-0">{{ $order->shipping_address }}, {{ $order->shipping_city }}, {{ $order->shipping_province }} {{ $order->shipping_postal_code }}</p>
            @if($order->shipping_courier)
            <hr>
            <p class="small mb-0"><strong>Kurir:</strong> {{ strtoupper($order->shipping_courier) }}</p>
            @endif
        </div>

        <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-secondary w-100">
            <i class="bi bi-arrow-left me-2"></i>Kembali
        </a>
    </div>
</div>
@endsection

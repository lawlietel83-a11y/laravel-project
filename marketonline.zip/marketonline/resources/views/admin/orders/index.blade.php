@extends('layouts.admin')
@section('title','Pesanan')
@section('page-title','Manajemen Pesanan')
@section('content')
<div class="card p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0">Semua Pesanan</h6>
    </div>
    <form class="row g-2 mb-4" method="GET">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control form-control-sm"
                   placeholder="No. pesanan / nama pembeli…" value="{{ request('search') }}">
        </div>
        <div class="col-md-2">
            <select name="status" class="form-select form-select-sm">
                <option value="">Semua Status</option>
                @foreach(['pending'=>'Pending','paid'=>'Dibayar','processing'=>'Diproses','shipped'=>'Dikirim','completed'=>'Selesai','cancelled'=>'Dibatalkan'] as $val=>$lbl)
                <option value="{{ $val }}" {{ request('status')===$val?'selected':'' }}>{{ $lbl }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-2">
            <input type="date" name="from" class="form-control form-control-sm" value="{{ request('from') }}">
        </div>
        <div class="col-md-2">
            <input type="date" name="to" class="form-control form-control-sm" value="{{ request('to') }}">
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary btn-sm w-100">Filter</button>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>No. Pesanan</th><th>Pembeli</th><th>Seller</th>
                    <th>Total</th><th>Pembayaran</th><th>Status</th><th>Tanggal</th><th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($orders as $order)
                <tr>
                    <td class="fw-semibold small">#{{ $order->order_number }}</td>
                    <td class="small">{{ $order->buyer->name }}</td>
                    <td class="small">{{ $order->seller->name }}</td>
                    <td class="fw-semibold text-danger small">{{ $order->formatted_total }}</td>
                    <td>
                        <span class="badge {{ $order->payment_status==='paid'?'bg-success':'bg-warning text-dark' }}">
                            {{ $order->payment_status==='paid'?'Dibayar':'Belum Bayar' }}
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-{{ $order->status_label['class'] }}">{{ $order->status_label['label'] }}</span>
                    </td>
                    <td class="text-muted small">{{ $order->created_at->format('d M Y') }}</td>
                    <td>
                        <a href="{{ route('admin.orders.show',$order) }}" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-eye"></i>
                        </a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="text-center py-5 text-muted">Tidak ada pesanan ditemukan.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $orders->links() }}
</div>
@endsection

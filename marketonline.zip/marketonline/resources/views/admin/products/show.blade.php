@extends('layouts.admin')
@section('title','Detail Produk')
@section('page-title','Detail Produk')
@section('content')
<div class="row g-4">
    <div class="col-md-5">
        <div class="card p-4 text-center mb-4">
            <img src="{{ $product->image_url }}" class="img-fluid rounded mb-3" style="max-height:300px;object-fit:contain;" alt="">
            <h5 class="fw-bold">{{ $product->name }}</h5>
            <p class="text-danger fw-bold fs-4">{{ $product->formatted_price }}</p>
            <div class="d-flex justify-content-center gap-2">
                <span class="badge {{ $product->is_active ? 'bg-success':'bg-secondary' }}">{{ $product->is_active ? 'Aktif':'Nonaktif' }}</span>
                <span class="badge bg-info text-dark">{{ $product->condition === 'new' ? 'Baru':'Bekas' }}</span>
                <span class="badge bg-warning text-dark">Stok: {{ $product->stock }}</span>
            </div>
        </div>
        <div class="card p-4">
            <h6 class="fw-bold mb-3">Aksi</h6>
            <form action="{{ route('admin.products.toggle',$product) }}" method="POST" class="mb-2">
                @csrf @method('PATCH')
                <button class="btn {{ $product->is_active ? 'btn-outline-secondary':'btn-outline-success' }} btn-sm w-100">
                    <i class="bi {{ $product->is_active ? 'bi-pause-circle':'bi-play-circle' }} me-2"></i>
                    {{ $product->is_active ? 'Nonaktifkan':'Aktifkan' }}
                </button>
            </form>
            <form action="{{ route('admin.products.destroy',$product) }}" method="POST"
                  onsubmit="return confirm('Hapus produk ini?')">
                @csrf @method('DELETE')
                <button class="btn btn-outline-danger btn-sm w-100">
                    <i class="bi bi-trash me-2"></i>Hapus Produk
                </button>
            </form>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3">Informasi Produk</h6>
            <table class="table table-sm">
                <tr><td class="text-muted w-40">Nama</td><td class="fw-semibold">{{ $product->name }}</td></tr>
                <tr><td class="text-muted">SKU</td><td>{{ $product->sku ?? '-' }}</td></tr>
                <tr><td class="text-muted">Kategori</td><td>{{ $product->category->name }}</td></tr>
                <tr><td class="text-muted">Seller</td><td>{{ $product->seller->name }}</td></tr>
                <tr><td class="text-muted">Harga</td><td class="text-danger fw-bold">{{ $product->formatted_price }}</td></tr>
                <tr><td class="text-muted">Stok</td><td>{{ $product->stock }}</td></tr>
                <tr><td class="text-muted">Berat</td><td>{{ $product->weight }}g</td></tr>
                <tr><td class="text-muted">Kondisi</td><td>{{ $product->condition === 'new' ? 'Baru':'Bekas' }}</td></tr>
                <tr><td class="text-muted">Ditambah</td><td>{{ $product->created_at->format('d M Y') }}</td></tr>
            </table>
        </div>

        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3">Deskripsi</h6>
            <p class="text-muted small" style="white-space:pre-line">{{ $product->description }}</p>
        </div>

        @if($product->reviews->count())
        <div class="card p-4">
            <h6 class="fw-bold mb-3">Ulasan ({{ $product->reviews->count() }})</h6>
            @foreach($product->reviews->take(5) as $review)
            <div class="border-bottom pb-2 mb-2">
                <div class="d-flex justify-content-between">
                    <span class="fw-semibold small">{{ $review->user->name }}</span>
                    <div class="text-warning small">
                        @for($i=1;$i<=5;$i++)<i class="bi bi-star{{ $i<=$review->rating?'-fill':'' }}"></i>@endfor
                    </div>
                </div>
                <p class="small text-muted mb-0">{{ $review->comment }}</p>
            </div>
            @endforeach
        </div>
        @endif
    </div>
</div>
<div class="mt-3">
    <a href="{{ route('admin.products.index') }}" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-2"></i>Kembali
    </a>
</div>
@endsection

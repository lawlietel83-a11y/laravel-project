@extends('layouts.admin')
@section('title','Produk')
@section('page-title','Manajemen Produk')
@section('content')
<div class="card p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0">Semua Produk</h6>
    </div>
    <form class="row g-2 mb-4" method="GET">
        <div class="col-md-5">
            <input type="text" name="search" class="form-control form-control-sm"
                   placeholder="Cari nama produk…" value="{{ request('search') }}">
        </div>
        <div class="col-md-2">
            <select name="status" class="form-select form-select-sm">
                <option value="">Semua</option>
                <option value="active" {{ request('status')==='active'?'selected':'' }}>Aktif</option>
                <option value="trashed" {{ request('status')==='trashed'?'selected':'' }}>Dihapus</option>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary btn-sm">Filter</button>
            <a href="{{ route('admin.products.index') }}" class="btn btn-outline-secondary btn-sm ms-1">Reset</a>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr><th>Gambar</th><th>Nama</th><th>Seller</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
                @forelse($products as $p)
                <tr class="{{ $p->trashed() ? 'table-secondary':'' }}">
                    <td><img src="{{ $p->image_url }}" width="48" height="48" class="rounded" style="object-fit:cover"></td>
                    <td>
                        <div class="fw-semibold small">{{ Str::limit($p->name,35) }}</div>
                        <div class="text-muted" style="font-size:.75rem">SKU: {{ $p->sku ?? '-' }}</div>
                    </td>
                    <td class="small">{{ $p->seller->name }}</td>
                    <td class="small">{{ $p->category->name }}</td>
                    <td class="fw-semibold small text-danger">{{ $p->formatted_price }}</td>
                    <td><span class="badge {{ $p->stock > 5 ? 'bg-success': ($p->stock > 0 ? 'bg-warning text-dark':'bg-danger') }}">
                        {{ $p->stock }}
                    </span></td>
                    <td>
                        @if($p->trashed())
                            <span class="badge bg-secondary">Dihapus</span>
                        @else
                            <span class="badge {{ $p->is_active ? 'bg-success':'bg-secondary' }}">
                                {{ $p->is_active ? 'Aktif':'Nonaktif' }}
                            </span>
                        @endif
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            @if(!$p->trashed())
                            <a href="{{ route('admin.products.show',$p) }}" class="btn btn-outline-info btn-sm" title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            <form action="{{ route('admin.products.toggle',$p) }}" method="POST">
                                @csrf @method('PATCH')
                                <button class="btn btn-sm {{ $p->is_active ? 'btn-outline-secondary':'btn-outline-success' }}">
                                    <i class="bi {{ $p->is_active ? 'bi-pause':'bi-play' }}"></i>
                                </button>
                            </form>
                            <form action="{{ route('admin.products.destroy',$p) }}" method="POST"
                                  onsubmit="return confirm('Hapus produk ini?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash"></i></button>
                            </form>
                            @else
                            <form action="{{ route('admin.products.restore',$p->id) }}" method="POST">
                                @csrf
                                <button class="btn btn-outline-success btn-sm" title="Pulihkan">
                                    <i class="bi bi-arrow-counterclockwise"></i>
                                </button>
                            </form>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="text-center py-5 text-muted">Tidak ada produk.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $products->links() }}
</div>
@endsection

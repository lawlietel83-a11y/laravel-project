@extends('layouts.admin')
@section('title','Detail User')
@section('page-title','Detail User')
@section('content')
<div class="row g-4">
    <div class="col-md-4">
        <div class="card p-4 text-center">
            <div class="bg-primary rounded-circle text-white d-flex align-items-center justify-content-center mx-auto mb-3"
                 style="width:80px;height:80px;font-size:2rem">
                {{ strtoupper(substr($user->name,0,1)) }}
            </div>
            <h5 class="fw-bold">{{ $user->name }}</h5>
            <p class="text-muted small">{{ $user->email }}</p>
            @foreach($user->roles as $role)
            <span class="badge {{ $role->name==='admin'?'bg-danger':($role->name==='seller'?'bg-primary':'bg-success') }} mb-2">
                {{ ucfirst($role->name) }}
            </span>
            @endforeach
            <hr>
            <div class="text-start small">
                <p><i class="bi bi-telephone me-2 text-muted"></i>{{ $user->phone ?? '-' }}</p>
                <p><i class="bi bi-geo-alt me-2 text-muted"></i>{{ $user->city ? $user->city.', '.$user->province : '-' }}</p>
                <p class="mb-0"><i class="bi bi-calendar me-2 text-muted"></i>Bergabung {{ $user->created_at->format('d M Y') }}</p>
            </div>
            <hr>
            <a href="{{ route('admin.users.edit',$user) }}" class="btn btn-primary btn-sm w-100">
                <i class="bi bi-pencil me-2"></i>Edit User
            </a>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3">Pesanan Terbaru</h6>
            @forelse($user->orders->take(5) as $order)
            <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-2">
                <div>
                    <a href="{{ route('admin.orders.show',$order) }}" class="fw-semibold small text-decoration-none">
                        #{{ $order->order_number }}
                    </a>
                    <div class="text-muted small">{{ $order->created_at->format('d M Y') }}</div>
                </div>
                <div class="text-end">
                    <div class="fw-semibold small">{{ $order->formatted_total }}</div>
                    <span class="badge bg-{{ $order->status_label['class'] }}" style="font-size:.7rem">{{ $order->status_label['label'] }}</span>
                </div>
            </div>
            @empty
            <p class="text-muted small text-center py-3">Belum ada pesanan.</p>
            @endforelse
        </div>
        @if($user->hasRole('seller') && $user->products->count())
        <div class="card p-4">
            <h6 class="fw-bold mb-3">Produk Seller</h6>
            @foreach($user->products->take(5) as $product)
            <div class="d-flex gap-3 align-items-center border-bottom pb-2 mb-2">
                <img src="{{ $product->image_url }}" width="44" height="44" class="rounded" style="object-fit:cover">
                <div class="flex-grow-1 small">
                    <div class="fw-semibold">{{ Str::limit($product->name,40) }}</div>
                    <div class="text-muted">Stok: {{ $product->stock }}</div>
                </div>
                <div class="fw-semibold small text-danger">{{ $product->formatted_price }}</div>
            </div>
            @endforeach
        </div>
        @endif
    </div>
</div>
@endsection

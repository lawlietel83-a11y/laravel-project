@extends('layouts.app')
@section('title','Akses Ditolak')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center py-5">
            <div style="font-size:6rem;color:#e53935">403</div>
            <h3 class="fw-bold mb-3">Akses Ditolak</h3>
            <p class="text-muted mb-4">{{ $exception->getMessage() ?? 'Anda tidak memiliki izin untuk mengakses halaman ini.' }}</p>
            <a href="{{ url()->previous() }}" class="btn btn-outline-secondary me-2">
                <i class="bi bi-arrow-left me-1"></i>Kembali
            </a>
            <a href="{{ route('buyer.home') }}" class="btn btn-primary">
                <i class="bi bi-house me-1"></i>Beranda
            </a>
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')
@section('title','Halaman Tidak Ditemukan')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center py-5">
            <div style="font-size:6rem;color:#e53935">404</div>
            <h3 class="fw-bold mb-3">Halaman Tidak Ditemukan</h3>
            <p class="text-muted mb-4">Maaf, halaman yang Anda cari tidak ada atau telah dipindahkan.</p>
            <a href="{{ url()->previous() }}" class="btn btn-outline-secondary me-2">
                <i class="bi bi-arrow-left me-1"></i>Kembali
            </a>
            <a href="{{ route('buyer.home') }}" class="btn btn-primary">
                <i class="bi bi-house me-1"></i>Beranda
            </a>
        </div>
    </div>
</div>
@endsection

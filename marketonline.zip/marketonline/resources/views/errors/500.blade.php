@extends('layouts.app')
@section('title','Server Error')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center py-5">
            <div style="font-size:6rem;color:#e53935">500</div>
            <h3 class="fw-bold mb-3">Terjadi Kesalahan Server</h3>
            <p class="text-muted mb-4">Maaf, terjadi kesalahan pada server. Silakan coba lagi nanti.</p>
            <a href="{{ route('buyer.home') }}" class="btn btn-primary">
                <i class="bi bi-house me-1"></i>Kembali ke Beranda
            </a>
        </div>
    </div>
</div>
@endsection

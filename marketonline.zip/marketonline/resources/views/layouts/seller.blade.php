<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title','Seller') – MarketOnline Seller</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root{ --sidebar-w:240px; --primary:#1565c0; }
        body{ background:#f0f2f5; font-family:'Segoe UI',sans-serif; }
        #sidebar{
            position:fixed; top:0; left:0; height:100vh;
            width:var(--sidebar-w); background:#0d1b2a; z-index:1040;
            overflow-y:auto;
        }
        #sidebar .brand{ padding:20px 16px; color:#fff; font-size:1.2rem; font-weight:800; }
        #sidebar .brand span{ color:#42a5f5; }
        #sidebar .nav-link{ color:#aaa; padding:10px 16px; border-radius:8px;
            margin:2px 8px; display:flex; align-items:center; gap:10px; font-size:.9rem; }
        #sidebar .nav-link:hover, #sidebar .nav-link.active{ background:rgba(66,165,245,.15); color:#fff; }
        #sidebar .nav-section{ color:#555; font-size:.7rem; letter-spacing:1px;
            padding:12px 16px 4px; text-transform:uppercase; }
        #main{ margin-left:var(--sidebar-w); }
        .topbar{ background:#fff; padding:12px 24px; box-shadow:0 2px 8px rgba(0,0,0,.06); }
        .card{ border:none; border-radius:12px; box-shadow:0 2px 12px rgba(0,0,0,.06); }
        .btn-primary{ background:var(--primary); border-color:var(--primary); }
        .table th{ font-weight:600; font-size:.85rem; color:#666; }
    </style>
    @stack('styles')
</head>
<body>
<nav id="sidebar">
    <div class="brand"><span>Seller</span> Panel</div>
    <div class="nav-section">Menu</div>
    <a href="{{ route('seller.dashboard') }}" class="nav-link {{ request()->routeIs('seller.dashboard') ? 'active':'' }}">
        <i class="bi bi-house"></i> Dashboard
    </a>
    <a href="{{ route('seller.products.index') }}" class="nav-link {{ request()->routeIs('seller.products.*') ? 'active':'' }}">
        <i class="bi bi-box-seam"></i> Produk Saya
    </a>
    <a href="{{ route('seller.products.create') }}" class="nav-link">
        <i class="bi bi-plus-circle"></i> Tambah Produk
    </a>
    <a href="{{ route('seller.orders.index') }}" class="nav-link {{ request()->routeIs('seller.orders.*') ? 'active':'' }}">
        <i class="bi bi-receipt"></i> Pesanan
    </a>
    <div class="nav-section">Akun</div>
    <a href="{{ route('buyer.home') }}" class="nav-link">
        <i class="bi bi-shop"></i> Lihat Toko
    </a>
    <form action="{{ route('logout') }}" method="POST" class="px-2">
        @csrf
        <button class="nav-link w-100 text-start border-0 bg-transparent text-danger">
            <i class="bi bi-box-arrow-right"></i> Logout
        </button>
    </form>
</nav>

<div id="main">
    <div class="topbar d-flex align-items-center justify-content-between">
        <h6 class="mb-0 fw-bold">@yield('page-title','Dashboard')</h6>
        <div class="d-flex align-items-center gap-2">
            <span class="text-muted small">{{ auth()->user()->name }}</span>
            <span class="badge bg-primary">Seller</span>
        </div>
    </div>
    <div class="p-4">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-triangle me-2"></i>{{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if($errors->any())
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @yield('content')
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
@stack('scripts')
</body>
</html>

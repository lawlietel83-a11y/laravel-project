<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'MarketOnline') – Belanja Mudah & Terpercaya</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #e53935;
            --primary-dark: #b71c1c;
            --secondary: #ff7043;
        }
        body { background: #f5f5f5; font-family: 'Segoe UI', sans-serif; }
        .navbar-brand span { color: var(--primary); font-weight: 800; font-size: 1.5rem; }
        .navbar { background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,.08); }
        .btn-primary { background: var(--primary); border-color: var(--primary); }
        .btn-primary:hover { background: var(--primary-dark); border-color: var(--primary-dark); }
        .badge-cart { position: absolute; top: -6px; right: -8px; background: var(--primary); }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,.06); }
        .card-product:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(0,0,0,.12); transition: .3s; }
        .product-img { height: 200px; object-fit: cover; border-radius: 12px 12px 0 0; width: 100%; }
        .price-tag { color: var(--primary); font-weight: 700; font-size: 1.1rem; }
        .section-title { font-weight: 700; color: #222; border-left: 4px solid var(--primary); padding-left: 12px; }
        footer { background: #222; color: #aaa; }
        footer a { color: #aaa; text-decoration: none; }
        footer a:hover { color: #fff; }
        .alert { border-radius: 10px; }
    </style>
    @stack('styles')
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand" href="{{ route('buyer.home') }}">
            <span>Market</span>Online
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <form class="d-flex mx-auto w-50" action="{{ route('buyer.search') }}" method="GET">
                <input class="form-control me-2" type="search" name="q" placeholder="Cari produk…"
                       value="{{ request('q') }}">
                <button class="btn btn-primary px-3" type="submit"><i class="bi bi-search"></i></button>
            </form>
            <ul class="navbar-nav ms-auto align-items-center gap-1">
                @auth
                    @if(!auth()->user()->hasRole('admin') && !auth()->user()->hasRole('seller'))
                    <li class="nav-item">
                        <a class="nav-link position-relative" href="{{ route('buyer.cart') }}">
                            <i class="bi bi-cart3 fs-5"></i>
                            @php $cartCount = \App\Models\Cart::where('user_id',auth()->id())->count(); @endphp
                            @if($cartCount > 0)
                                <span class="badge rounded-pill badge-cart">{{ $cartCount }}</span>
                            @endif
                        </a>
                    </li>
                    @endif
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
                            <img src="{{ auth()->user()->avatar_url }}" class="rounded-circle" width="30" height="30"
                                 style="object-fit:cover" alt="">
                            {{ auth()->user()->name }}
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            @if(auth()->user()->hasRole('admin'))
                                <li><a class="dropdown-item" href="{{ route('admin.dashboard') }}"><i class="bi bi-speedometer2 me-2"></i>Dashboard Admin</a></li>
                            @elseif(auth()->user()->hasRole('seller'))
                                <li><a class="dropdown-item" href="{{ route('seller.dashboard') }}"><i class="bi bi-shop me-2"></i>Dashboard Seller</a></li>
                            @else
                                <li><a class="dropdown-item" href="{{ route('buyer.orders.index') }}"><i class="bi bi-bag me-2"></i>Pesanan Saya</a></li>
                                <li><a class="dropdown-item" href="{{ route('buyer.tracking') }}"><i class="bi bi-truck me-2"></i>Lacak Pesanan</a></li>
                            @endif
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="{{ route('logout') }}" method="POST">
                                    @csrf
                                    <button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                @else
                    <li class="nav-item"><a class="nav-link" href="{{ route('login') }}">Masuk</a></li>
                    <li class="nav-item"><a class="btn btn-primary btn-sm px-3" href="{{ route('register') }}">Daftar</a></li>
                @endauth
            </ul>
        </div>
    </div>
</nav>

<!-- Flash Messages -->
<div class="container mt-3">
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle me-2"></i>{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if($errors->any())
        <div class="alert alert-danger alert-dismissible fade show">
            <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
</div>

<main class="py-4">
    @yield('content')
</main>

<footer class="pt-5 pb-3 mt-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <h5 class="text-white fw-bold mb-3"><span style="color:var(--primary)">Market</span>Online</h5>
                <p class="small">Platform marketplace terpercaya untuk jual beli produk berkualitas.</p>
            </div>
            <div class="col-md-2">
                <h6 class="text-white">Belanja</h6>
                <ul class="list-unstyled small">
                    <li><a href="{{ route('buyer.home') }}">Beranda</a></li>
                    <li><a href="{{ route('buyer.search') }}">Semua Produk</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h6 class="text-white">Akun</h6>
                <ul class="list-unstyled small">
                    @auth
                    <li><a href="{{ route('buyer.orders.index') }}">Pesanan Saya</a></li>
                    @else
                    <li><a href="{{ route('login') }}">Masuk</a></li>
                    <li><a href="{{ route('register') }}">Daftar</a></li>
                    @endauth
                </ul>
            </div>
            <div class="col-md-3">
                <h6 class="text-white">Kontak</h6>
                <p class="small">Email: info@marketonline.com<br>WA: 0800-1234-5678</p>
            </div>
        </div>
        <hr style="border-color:#444">
        <p class="text-center small mb-0">&copy; {{ date('Y') }} MarketOnline. All rights reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
@stack('scripts')
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title','Admin') – MarketOnline Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root{ --sidebar-w:240px; --primary:#e53935; }
        body{ background:#f0f2f5; font-family:'Segoe UI',sans-serif; }
        #sidebar{
            position:fixed; top:0; left:0; height:100vh;
            width:var(--sidebar-w); background:#1a1a2e; z-index:1040;
            overflow-y:auto; transition:.3s;
        }
        #sidebar .brand{ padding:20px 16px; color:#fff; font-size:1.2rem; font-weight:800; }
        #sidebar .brand span{ color:var(--primary); }
        #sidebar .nav-link{ color:#aaa; padding:10px 16px; border-radius:8px; margin:2px 8px;
            display:flex; align-items:center; gap:10px; font-size:.9rem; }
        #sidebar .nav-link:hover, #sidebar .nav-link.active{ background:rgba(229,57,53,.15); color:#fff; }
        #sidebar .nav-section{ color:#555; font-size:.7rem; letter-spacing:1px;
            padding:12px 16px 4px; text-transform:uppercase; }
        #main{ margin-left:var(--sidebar-w); }
        .topbar{ background:#fff; padding:12px 24px; box-shadow:0 2px 8px rgba(0,0,0,.06);
            display:flex; align-items:center; justify-content:space-between; }
        .card{ border:none; border-radius:12px; box-shadow:0 2px 12px rgba(0,0,0,.06); }
        .stat-card{ border-left:4px solid var(--primary); }
        .btn-primary{ background:var(--primary); border-color:var(--primary); }
        .table th{ font-weight:600; font-size:.85rem; color:#666; }
        @media(max-width:768px){
            #sidebar{ transform:translateX(-100%); }
            #main{ margin-left:0; }
        }
    </style>
    @stack('styles')
</head>
<body>
<!-- Sidebar -->
<nav id="sidebar">
    <div class="brand"><span>Market</span>Online</div>
    <div class="nav-section">Menu Utama</div>
    <a href="{{ route('admin.dashboard') }}" class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active':'' }}">
        <i class="bi bi-speedometer2"></i> Dashboard
    </a>
    <div class="nav-section">Manajemen</div>
    <a href="{{ route('admin.users.index') }}" class="nav-link {{ request()->routeIs('admin.users.*') ? 'active':'' }}">
        <i class="bi bi-people"></i> Pengguna
    </a>
    <a href="{{ route('admin.categories.index') }}" class="nav-link {{ request()->routeIs('admin.categories.*') ? 'active':'' }}">
        <i class="bi bi-tags"></i> Kategori
    </a>
    <a href="{{ route('admin.products.index') }}" class="nav-link {{ request()->routeIs('admin.products.*') ? 'active':'' }}">
        <i class="bi bi-box-seam"></i> Produk
    </a>
    <a href="{{ route('admin.orders.index') }}" class="nav-link {{ request()->routeIs('admin.orders.*') ? 'active':'' }}">
        <i class="bi bi-receipt"></i> Pesanan
    </a>
    <div class="nav-section">Akun</div>
    <a href="{{ route('buyer.home') }}" class="nav-link">
        <i class="bi bi-shop"></i> Lihat Toko
    </a>
    <form action="{{ route('logout') }}" method="POST" class="px-2">
        @csrf
        <button class="nav-link w-100 text-start border-0 bg-transparent text-danger">
            <i class="bi bi-box-arrow-right"></i> Logout
        </button>
    </form>
</nav>

<!-- Main Content -->
<div id="main">
    <div class="topbar">
        <h6 class="mb-0 fw-bold">@yield('page-title','Dashboard')</h6>
        <div class="d-flex align-items-center gap-3">
            <span class="text-muted small">{{ auth()->user()->name }}</span>
            <span class="badge bg-danger">Admin</span>
        </div>
    </div>

    <div class="p-4">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-triangle me-2"></i>{{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if($errors->any())
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @yield('content')
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
@stack('scripts')
</body>
</html>

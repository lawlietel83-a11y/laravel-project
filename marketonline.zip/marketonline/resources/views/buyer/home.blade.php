@extends('layouts.app')
@section('title','Beranda')
@section('content')
<div class="container">
    <!-- Hero Banner -->
    <div class="rounded-4 p-5 mb-5 text-white" style="background:linear-gradient(135deg,#e53935,#ff7043);">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h1 class="fw-bold display-5 mb-3">Belanja Mudah,<br>Terpercaya & Hemat</h1>
                <p class="lead mb-4">Temukan ribuan produk pilihan dari seller terpercaya di seluruh Indonesia.</p>
                <a href="{{ route('buyer.search') }}" class="btn btn-light btn-lg px-5 fw-semibold text-danger">
                    <i class="bi bi-search me-2"></i>Mulai Belanja
                </a>
            </div>
            <div class="col-md-5 text-center d-none d-md-block">
                <i class="bi bi-bag-heart" style="font-size:9rem;opacity:.3;"></i>
            </div>
        </div>
    </div>

    <!-- Categories -->
    <h5 class="section-title mb-4">Kategori Populer</h5>
    <div class="row g-3 mb-5">
        @foreach($categories as $cat)
        <div class="col-6 col-md-3 col-lg-2">
            <a href="{{ route('buyer.search', ['category_id' => $cat->id]) }}"
               class="card text-center text-decoration-none p-3 h-100">
                <div class="fs-2 mb-2">
                    @php
                        $icons = ['bi-cpu','bi-person','bi-gender-female','bi-cup-hot','bi-house','bi-bicycle','bi-book','bi-heart-pulse'];
                        echo '<i class="bi ' . ($icons[$loop->index % count($icons)] ?? 'bi-tag') . ' text-danger"></i>';
                    @endphp
                </div>
                <small class="fw-semibold text-dark">{{ $cat->name }}</small>
            </a>
        </div>
        @endforeach
    </div>

    <!-- Featured Products -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="section-title mb-0">Produk Terbaru</h5>
        <a href="{{ route('buyer.search') }}" class="btn btn-outline-danger btn-sm">Lihat Semua</a>
    </div>
    <div class="row g-4 mb-5">
        @forelse($featuredProducts as $product)
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card card-product h-100">
                <a href="{{ route('buyer.product.detail', $product->slug) }}">
                    <img src="{{ $product->image_url }}" class="product-img" alt="{{ $product->name }}">
                </a>
                <div class="card-body p-3">
                    <p class="small text-muted mb-1">{{ $product->category?->name }}</p>
                    <a href="{{ route('buyer.product.detail', $product->slug) }}"
                       class="text-dark text-decoration-none fw-semibold d-block mb-2"
                       style="font-size:.9rem;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
                        {{ $product->name }}
                    </a>
                    <div class="price-tag">{{ $product->formatted_price }}</div>
                    <p class="small text-muted mt-1 mb-0">
                        <i class="bi bi-shop me-1"></i>{{ $product->seller->name }}
                    </p>
                </div>
                <div class="card-footer bg-white border-0 p-3 pt-0">
                    <form action="{{ route('buyer.cart.add') }}" method="POST">
                        @csrf
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        <input type="hidden" name="quantity" value="1">
                        @auth
                            @if(!auth()->user()->hasRole('seller') && !auth()->user()->hasRole('admin'))
                            <button class="btn btn-primary btn-sm w-100">
                                <i class="bi bi-cart-plus me-1"></i>Tambah
                            </button>
                            @endif
                        @else
                            <a href="{{ route('login') }}" class="btn btn-outline-danger btn-sm w-100">Masuk untuk beli</a>
                        @endauth
                    </form>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12">
            <div class="text-center py-5 text-muted">
                <i class="bi bi-box-seam fs-1"></i>
                <p class="mt-2">Belum ada produk tersedia.</p>
            </div>
        </div>
        @endforelse
    </div>
</div>
@endsection

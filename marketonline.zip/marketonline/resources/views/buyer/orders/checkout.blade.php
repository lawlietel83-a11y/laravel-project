@extends('layouts.app')
@section('title','Checkout')
@section('content')
<div class="container">
    <h4 class="fw-bold mb-4"><i class="bi bi-bag-check me-2"></i>Checkout</h4>
    <form action="{{ route('buyer.orders.place') }}" method="POST">
        @csrf
        <div class="row g-4">
            <!-- Shipping Address -->
            <div class="col-md-8">
                <div class="card p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="bi bi-geo-alt me-2 text-primary"></i>Alamat Pengiriman</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Nama Penerima</label>
                            <input type="text" name="shipping_name" class="form-control @error('shipping_name') is-invalid @enderror"
                                   value="{{ old('shipping_name', $user->name) }}" required>
                            @error('shipping_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">No. Telepon</label>
                            <input type="text" name="shipping_phone" class="form-control @error('shipping_phone') is-invalid @enderror"
                                   value="{{ old('shipping_phone', $user->phone) }}" required>
                            @error('shipping_phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Alamat Lengkap</label>
                            <textarea name="shipping_address" rows="2" class="form-control @error('shipping_address') is-invalid @enderror" required>{{ old('shipping_address', $user->address) }}</textarea>
                            @error('shipping_address')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Kota</label>
                            <input type="text" name="shipping_city" class="form-control @error('shipping_city') is-invalid @enderror"
                                   value="{{ old('shipping_city', $user->city) }}" required>
                            @error('shipping_city')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Provinsi</label>
                            <input type="text" name="shipping_province" class="form-control"
                                   value="{{ old('shipping_province', $user->province) }}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Kode Pos</label>
                            <input type="text" name="shipping_postal_code" class="form-control"
                                   value="{{ old('shipping_postal_code', $user->postal_code) }}" required>
                        </div>
                    </div>
                </div>

                <div class="card p-4 mb-4">
                    <h5 class="fw-bold mb-3"><i class="bi bi-truck me-2 text-primary"></i>Pilih Kurir</h5>
                    <div class="row g-3">
                        @foreach(['JNE','J&T Express','SiCepat','Anteraja','Pos Indonesia'] as $courier)
                        <div class="col-md-4">
                            <div class="form-check border rounded p-3">
                                <input class="form-check-input" type="radio" name="shipping_courier"
                                       id="courier{{ $loop->index }}" value="{{ $courier }}"
                                       {{ old('shipping_courier') === $courier || $loop->first ? 'checked':'' }}>
                                <label class="form-check-label fw-semibold" for="courier{{ $loop->index }}">
                                    {{ $courier }}<br><small class="text-muted">Reguler ~3-5 hari</small>
                                </label>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>

                <div class="card p-4">
                    <h5 class="fw-bold mb-3"><i class="bi bi-chat-left-text me-2 text-primary"></i>Catatan</h5>
                    <textarea name="notes" rows="3" class="form-control" placeholder="Catatan untuk seller (opsional)">{{ old('notes') }}</textarea>
                </div>
            </div>

            <!-- Order Summary -->
            <div class="col-md-4">
                <div class="card p-4 sticky-top" style="top:80px">
                    <h5 class="fw-bold mb-3">Ringkasan Pesanan</h5>
                    @foreach($cartItems as $item)
                    <div class="d-flex gap-2 mb-2 align-items-center">
                        <img src="{{ $item->product->image_url }}" width="44" height="44"
                             class="rounded" style="object-fit:cover;flex-shrink:0">
                        <div class="flex-grow-1 small">
                            <div>{{ Str::limit($item->product->name,28) }}</div>
                            <div class="text-muted">{{ $item->quantity }}x {{ $item->product->formatted_price }}</div>
                        </div>
                        <div class="fw-semibold small">Rp {{ number_format($item->product->price*$item->quantity,0,',','.') }}</div>
                    </div>
                    @endforeach
                    <hr>
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-muted small">Subtotal</span>
                        <strong>Rp {{ number_format($cartItems->sum(fn($i)=>$i->product->price*$i->quantity),0,',','.') }}</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-3">
                        <span class="text-muted small">Ongkos Kirim (est.)</span>
                        <span class="text-muted small">Rp 15.000/toko</span>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                        <i class="bi bi-bag-check me-2"></i>Buat Pesanan
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@extends('layouts.app')
@section('title','Pesanan Saya')
@section('content')
<div class="container">
    <h4 class="fw-bold mb-4"><i class="bi bi-bag me-2"></i>Pesanan Saya</h4>
    <!-- Status Filter Tabs -->
    <div class="card mb-4">
        <div class="card-body p-0">
            <ul class="nav nav-tabs nav-fill border-0">
                @foreach(['' => 'Semua', 'pending' => 'Menunggu Bayar', 'paid' => 'Dibayar', 'processing' => 'Diproses', 'shipped' => 'Dikirim', 'completed' => 'Selesai', 'cancelled' => 'Dibatalkan'] as $val => $label)
                <li class="nav-item">
                    <a class="nav-link {{ request('status') === $val ? 'active' : '' }}"
                       href="{{ route('buyer.orders.index', array_merge(request()->query(), ['status' => $val])) }}">
                        {{ $label }}
                    </a>
                </li>
                @endforeach
            </ul>
        </div>
    </div>

    @forelse($orders as $order)
    <div class="card mb-3">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <div>
                <span class="fw-semibold">#{{ $order->order_number }}</span>
                <span class="text-muted small ms-3">{{ $order->created_at->format('d M Y, H:i') }}</span>
            </div>
            <span class="badge bg-{{ $order->status_label['class'] }}">{{ $order->status_label['label'] }}</span>
        </div>
        <div class="card-body">
            <p class="small text-muted mb-2"><i class="bi bi-shop me-1"></i>{{ $order->seller->name }}</p>
            @foreach($order->items->take(3) as $item)
            <div class="d-flex gap-3 align-items-center mb-2">
                <img src="{{ $item->product_image ? asset('storage/'.$item->product_image) : asset('images/default-product.png') }}"
                     width="50" height="50" class="rounded" style="object-fit:cover">
                <div>
                    <div class="fw-semibold small">{{ $item->product_name }}</div>
                    <div class="text-muted small">{{ $item->quantity }} x {{ $item->formatted_price }}</div>
                </div>
            </div>
            @endforeach
            @if($order->items->count() > 3)
                <p class="text-muted small">+{{ $order->items->count()-3 }} produk lainnya</p>
            @endif
        </div>
        <div class="card-footer bg-white d-flex justify-content-between align-items-center">
            <div>
                <span class="text-muted small">Total: </span>
                <strong class="text-danger">{{ $order->formatted_total }}</strong>
            </div>
            <div class="d-flex gap-2">
                @if($order->status === 'pending')
                <a href="{{ route('buyer.orders.payment', $order) }}" class="btn btn-primary btn-sm">
                    <i class="bi bi-credit-card me-1"></i>Bayar
                </a>
                @endif
                @if($order->status === 'shipped')
                <form action="{{ route('buyer.orders.confirm', $order) }}" method="POST">
                    @csrf
                    <button class="btn btn-success btn-sm" onclick="return confirm('Konfirmasi pesanan diterima?')">
                        <i class="bi bi-check-circle me-1"></i>Terima
                    </button>
                </form>
                @endif
                <a href="{{ route('buyer.orders.show', $order) }}" class="btn btn-outline-secondary btn-sm">
                    Detail
                </a>
                @if($order->tracking_number)
                <a href="{{ route('buyer.tracking.show', $order) }}" class="btn btn-outline-info btn-sm">
                    <i class="bi bi-geo-alt me-1"></i>Lacak
                </a>
                @endif
            </div>
        </div>
    </div>
    @empty
    <div class="text-center py-5">
        <i class="bi bi-bag-x fs-1 text-muted"></i>
        <p class="text-muted mt-3">Belum ada pesanan.</p>
        <a href="{{ route('buyer.search') }}" class="btn btn-primary px-5">Belanja Sekarang</a>
    </div>
    @endforelse
    {{ $orders->links() }}
</div>
@endsection

@extends('layouts.app')
@section('title','Detail Pesanan')
@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0"><i class="bi bi-receipt me-2"></i>Detail Pesanan</h4>
        <a href="{{ route('buyer.orders.index') }}" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i>Kembali
        </a>
    </div>

    <div class="row g-4">
        <div class="col-md-8">
            <!-- Order Status -->
            <div class="card p-4 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="fw-bold mb-0">#{{{ $order->order_number }}}</h6>
                    <span class="badge bg-{{ $order->status_label['class'] }} fs-6">{{ $order->status_label['label'] }}</span>
                </div>
                <p class="text-muted small mb-0">Tanggal: {{ $order->created_at->format('d M Y, H:i') }}</p>
                @if($order->paid_at)<p class="text-muted small mb-0">Dibayar: {{ $order->paid_at->format('d M Y, H:i') }}</p>@endif
                @if($order->shipped_at)<p class="text-muted small mb-0">Dikirim: {{ $order->shipped_at->format('d M Y, H:i') }}</p>@endif
                @if($order->delivered_at)<p class="text-muted small mb-0">Diterima: {{ $order->delivered_at->format('d M Y, H:i') }}</p>@endif
            </div>

            <!-- Items -->
            <div class="card p-4 mb-4">
                <h6 class="fw-bold mb-3">Produk Dipesan</h6>
                @foreach($order->items as $item)
                <div class="d-flex gap-3 align-items-center border-bottom pb-3 mb-3">
                    <img src="{{ $item->product_image ? asset('storage/'.$item->product_image) : asset('images/default-product.png') }}"
                         width="64" height="64" class="rounded" style="object-fit:cover">
                    <div class="flex-grow-1">
                        <div class="fw-semibold">{{ $item->product_name }}</div>
                        <div class="text-muted small">{{ $item->quantity }} x {{ $item->formatted_price }}</div>
                    </div>
                    <div class="fw-bold text-danger">{{ $item->formatted_subtotal }}</div>
                </div>
                @endforeach
            </div>

            <!-- Shipping Info -->
            @if($order->shipment)
            <div class="card p-4 mb-4">
                <h6 class="fw-bold mb-3"><i class="bi bi-truck me-2"></i>Info Pengiriman</h6>
                <div class="row g-2">
                    <div class="col-md-6"><small class="text-muted">Kurir</small><p class="fw-semibold mb-0">{{ strtoupper($order->shipment->courier) }}</p></div>
                    <div class="col-md-6"><small class="text-muted">No. Resi</small><p class="fw-semibold mb-0">{{ $order->shipment->tracking_number ?? '-' }}</p></div>
                    <div class="col-md-6"><small class="text-muted">Status</small>
                        <p class="mb-0"><span class="badge bg-{{ $order->shipment->status_label['class'] }}">{{ $order->shipment->status_label['label'] }}</span></p>
                    </div>
                </div>
                @if($order->shipment->tracking_number)
                <div class="mt-3">
                    <a href="{{ route('buyer.tracking.show', $order) }}" class="btn btn-outline-info btn-sm">
                        <i class="bi bi-geo-alt me-1"></i>Lacak Paket
                    </a>
                </div>
                @endif
            </div>
            @endif
        </div>

        <div class="col-md-4">
            <!-- Payment Summary -->
            <div class="card p-4 mb-4">
                <h6 class="fw-bold mb-3">Ringkasan Pembayaran</h6>
                <div class="d-flex justify-content-between mb-2"><span class="text-muted small">Subtotal</span><span>Rp {{ number_format($order->subtotal,0,',','.') }}</span></div>
                <div class="d-flex justify-content-between mb-2"><span class="text-muted small">Ongkir</span><span>Rp {{ number_format($order->shipping_cost,0,',','.') }}</span></div>
                @if($order->discount > 0)
                <div class="d-flex justify-content-between mb-2 text-success"><span class="small">Diskon</span><span>-Rp {{ number_format($order->discount,0,',','.') }}</span></div>
                @endif
                <hr>
                <div class="d-flex justify-content-between fw-bold"><span>Total</span><span class="text-danger">{{ $order->formatted_total }}</span></div>
                @if($order->payment_method)
                <p class="small text-muted mt-2 mb-0">Metode: {{ strtoupper($order->payment_method) }}</p>
                @endif
            </div>

            <!-- Shipping Address -->
            <div class="card p-4 mb-4">
                <h6 class="fw-bold mb-3"><i class="bi bi-geo-alt me-2"></i>Alamat Pengiriman</h6>
                <p class="mb-1 fw-semibold">{{ $order->shipping_name }}</p>
                <p class="mb-1 small">{{ $order->shipping_phone }}</p>
                <p class="mb-0 small text-muted">{{ $order->shipping_address }}, {{ $order->shipping_city }}, {{ $order->shipping_province }} {{ $order->shipping_postal_code }}</p>
            </div>

            <!-- Actions -->
            <div class="card p-4">
                @if($order->status === 'pending')
                <a href="{{ route('buyer.orders.payment', $order) }}" class="btn btn-primary w-100 mb-2">
                    <i class="bi bi-credit-card me-2"></i>Bayar Sekarang
                </a>
                <form action="{{ route('buyer.orders.cancel', $order) }}" method="POST">
                    @csrf
                    <input type="hidden" name="cancel_reason" value="Pembeli membatalkan pesanan">
                    <button class="btn btn-outline-danger w-100 btn-sm" onclick="return confirm('Batalkan pesanan ini?')">
                        <i class="bi bi-x-circle me-2"></i>Batalkan
                    </button>
                </form>
                @endif
                @if($order->status === 'shipped')
                <form action="{{ route('buyer.orders.confirm', $order) }}" method="POST">
                    @csrf
                    <button class="btn btn-success w-100" onclick="return confirm('Konfirmasi pesanan sudah diterima?')">
                        <i class="bi bi-check-circle me-2"></i>Pesanan Diterima
                    </button>
                </form>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection

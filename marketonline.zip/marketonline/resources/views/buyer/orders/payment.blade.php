@extends('layouts.app')
@section('title','Pembayaran')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card p-5">
                <h4 class="fw-bold mb-1 text-center"><i class="bi bi-credit-card me-2 text-primary"></i>Pembayaran</h4>
                <p class="text-center text-muted small mb-4">Pesanan #{{ $order->order_number }}</p>

                <div class="alert alert-warning text-center mb-4">
                    <i class="bi bi-clock me-2"></i>
                    Selesaikan pembayaran sebelum pesanan dibatalkan otomatis
                </div>

                <!-- Total -->
                <div class="bg-light rounded p-4 text-center mb-4">
                    <p class="text-muted small mb-1">Total Pembayaran</p>
                    <h2 class="fw-bold text-danger mb-0">{{ $order->formatted_total }}</h2>
                </div>

                <!-- Order Items -->
                <div class="mb-4">
                    <h6 class="fw-bold mb-3">Detail Pesanan</h6>
                    @foreach($order->items as $item)
                    <div class="d-flex justify-content-between small mb-1">
                        <span>{{ $item->product_name }} (x{{ $item->quantity }})</span>
                        <span>{{ $item->formatted_subtotal }}</span>
                    </div>
                    @endforeach
                    <hr>
                    <div class="d-flex justify-content-between small">
                        <span class="text-muted">Subtotal</span>
                        <span>Rp {{ number_format($order->subtotal,0,',','.') }}</span>
                    </div>
                    <div class="d-flex justify-content-between small">
                        <span class="text-muted">Ongkir</span>
                        <span>Rp {{ number_format($order->shipping_cost,0,',','.') }}</span>
                    </div>
                </div>

                <!-- Payment Method -->
                <form action="{{ route('buyer.orders.pay', $order) }}" method="POST">
                    @csrf
                    <h6 class="fw-bold mb-3">Pilih Metode Pembayaran</h6>
                    <div class="row g-3 mb-4">
                        @foreach([
                            ['value'=>'transfer_bank','icon'=>'bi-bank','label'=>'Transfer Bank','desc'=>'BCA, Mandiri, BNI, BRI'],
                            ['value'=>'virtual_account','icon'=>'bi-upc-scan','label'=>'Virtual Account','desc'=>'Bayar via VA bank manapun'],
                            ['value'=>'qris','icon'=>'bi-qr-code','label'=>'QRIS','desc'=>'Scan QR Code'],
                            ['value'=>'cod','icon'=>'bi-cash','label'=>'COD','desc'=>'Bayar saat terima paket'],
                        ] as $method)
                        <div class="col-6">
                            <div class="form-check border rounded p-3 h-100">
                                <input class="form-check-input" type="radio" name="payment_method"
                                       id="pm_{{ $method['value'] }}" value="{{ $method['value'] }}"
                                       {{ $loop->first ? 'checked':'' }} required>
                                <label class="form-check-label w-100" for="pm_{{ $method['value'] }}">
                                    <i class="bi {{ $method['icon'] }} fs-4 d-block mb-1 text-primary"></i>
                                    <strong class="small">{{ $method['label'] }}</strong><br>
                                    <small class="text-muted">{{ $method['desc'] }}</small>
                                </label>
                            </div>
                        </div>
                        @endforeach
                    </div>

                    <div class="alert alert-info small">
                        <i class="bi bi-info-circle me-2"></i>
                        Ini adalah simulasi pembayaran. Klik tombol di bawah untuk mengkonfirmasi.
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-3 fw-bold fs-5">
                        <i class="bi bi-lock me-2"></i>Konfirmasi Pembayaran
                    </button>
                </form>

                <a href="{{ route('buyer.orders.show', $order) }}" class="btn btn-link w-100 text-muted mt-2">
                    Kembali ke Detail Pesanan
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')
@section('title','Keranjang Belanja')
@section('content')
<div class="container">
    <h4 class="fw-bold mb-4"><i class="bi bi-cart3 me-2"></i>Keranjang Belanja</h4>
    @if($cartItems->isEmpty())
        <div class="text-center py-5">
            <i class="bi bi-cart-x fs-1 text-muted"></i>
            <p class="text-muted mt-3">Keranjang Anda kosong.</p>
            <a href="{{ route('buyer.search') }}" class="btn btn-primary px-5">Mulai Belanja</a>
        </div>
    @else
    <div class="row g-4">
        <div class="col-md-8">
            @foreach($cartItems->groupBy('product.seller_id') as $sellerId => $items)
            <div class="card mb-3">
                <div class="card-header bg-white d-flex align-items-center gap-2">
                    <i class="bi bi-shop text-primary"></i>
                    <strong>{{ $items->first()->product->seller->shopProfile?->shop_name ?? $items->first()->product->seller->name }}</strong>
                </div>
                <div class="card-body p-0">
                    @foreach($items as $item)
                    <div class="d-flex gap-3 align-items-center p-3 border-bottom">
                        <img src="{{ $item->product->image_url }}" width="70" height="70"
                             class="rounded" style="object-fit:cover">
                        <div class="flex-grow-1">
                            <a href="{{ route('buyer.product.detail', $item->product->slug) }}"
                               class="text-dark fw-semibold text-decoration-none">
                                {{ $item->product->name }}
                            </a>
                            <div class="price-tag small mt-1">{{ $item->product->formatted_price }}</div>
                        </div>
                        <form action="{{ route('buyer.cart.update', $item) }}" method="POST" class="d-flex align-items-center gap-1">
                            @csrf @method('PATCH')
                            <div class="input-group" style="width:110px">
                                <button type="button" class="btn btn-outline-secondary btn-sm"
                                        onclick="this.nextElementSibling.value=Math.max(1,parseInt(this.nextElementSibling.value)-1);this.closest('form').submit()">-</button>
                                <input type="number" name="quantity" value="{{ $item->quantity }}" min="1"
                                       max="{{ $item->product->stock }}" class="form-control form-control-sm text-center"
                                       onchange="this.closest('form').submit()">
                                <button type="button" class="btn btn-outline-secondary btn-sm"
                                        onclick="this.previousElementSibling.value=parseInt(this.previousElementSibling.value)+1;this.closest('form').submit()">+</button>
                            </div>
                        </form>
                        <div class="fw-bold" style="width:120px;text-align:right">
                            Rp {{ number_format($item->product->price * $item->quantity, 0, ',', '.') }}
                        </div>
                        <form action="{{ route('buyer.cart.remove', $item) }}" method="POST">
                            @csrf @method('DELETE')
                            <button class="btn btn-link text-danger p-0"><i class="bi bi-trash"></i></button>
                        </form>
                    </div>
                    @endforeach
                </div>
            </div>
            @endforeach

            <div class="d-flex justify-content-between">
                <form action="{{ route('buyer.cart.clear') }}" method="POST">
                    @csrf @method('DELETE')
                    <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Kosongkan keranjang?')">
                        <i class="bi bi-trash me-1"></i>Kosongkan
                    </button>
                </form>
                <a href="{{ route('buyer.search') }}" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-arrow-left me-1"></i>Lanjut Belanja
                </a>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card p-4 sticky-top" style="top:80px">
                <h5 class="fw-bold mb-3">Ringkasan Belanja</h5>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Total ({{ $cartItems->sum('quantity') }} produk)</span>
                    <strong>Rp {{ number_format($total,0,',','.') }}</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Ongkos Kirim (est.)</span>
                    <span class="text-success small">Dihitung di checkout</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-4">
                    <strong>Total</strong>
                    <strong class="text-danger fs-5">Rp {{ number_format($total,0,',','.') }}</strong>
                </div>
                <a href="{{ route('buyer.checkout') }}" class="btn btn-primary w-100 py-2 fw-semibold">
                    <i class="bi bi-bag-check me-2"></i>Checkout Sekarang
                </a>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection

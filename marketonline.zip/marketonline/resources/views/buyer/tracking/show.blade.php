@extends('layouts.app')
@section('title','Tracking Pesanan')
@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0"><i class="bi bi-truck me-2"></i>Tracking Pesanan</h4>
        <a href="{{ route('buyer.tracking') }}" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i>Kembali
        </a>
    </div>

    <div class="row g-4">
        <div class="col-md-7">
            <!-- Tracking Timeline -->
            <div class="card p-4 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h6 class="fw-bold mb-0">{{ $order->order_number }}</h6>
                        <small class="text-muted">
                            @if($order->shipment)
                                {{ strtoupper($order->shipment->courier) }}
                                @if($order->shipment->tracking_number)
                                    – Resi: <strong>{{ $order->shipment->tracking_number }}</strong>
                                @endif
                            @endif
                        </small>
                    </div>
                    <span class="badge bg-{{ $order->status_label['class'] }} fs-6">
                        {{ $order->status_label['label'] }}
                    </span>
                </div>

                <!-- Progress Steps -->
                <div class="d-flex justify-content-between position-relative mb-4" style="padding:0 10px">
                    <div style="position:absolute;top:20px;left:20px;right:20px;height:3px;background:#dee2e6;z-index:0"></div>
                    @php
                        $steps = [
                            ['key'=>'pending',   'icon'=>'bi-receipt',      'label'=>'Pesanan'],
                            ['key'=>'paid',      'icon'=>'bi-credit-card',  'label'=>'Dibayar'],
                            ['key'=>'processing','icon'=>'bi-box-seam',     'label'=>'Diproses'],
                            ['key'=>'shipped',   'icon'=>'bi-truck',        'label'=>'Dikirim'],
                            ['key'=>'completed', 'icon'=>'bi-house-check',  'label'=>'Diterima'],
                        ];
                        $statusOrder = ['pending'=>0,'paid'=>1,'processing'=>2,'shipped'=>3,'delivered'=>4,'completed'=>4];
                        $currentStep = $statusOrder[$order->status] ?? 0;
                    @endphp
                    @foreach($steps as $i => $step)
                    <div class="text-center" style="z-index:1;flex:1">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-1"
                             style="width:40px;height:40px;background:{{ $i <= $currentStep ? '#e53935':'#dee2e6' }};color:{{ $i <= $currentStep ? '#fff':'#aaa' }}">
                            <i class="bi {{ $step['icon'] }} fs-6"></i>
                        </div>
                        <div style="font-size:.7rem;color:{{ $i <= $currentStep ? '#e53935':'#aaa' }};font-weight:{{ $i <= $currentStep ? '600':'400' }}">
                            {{ $step['label'] }}
                        </div>
                    </div>
                    @endforeach
                </div>

                <!-- Timeline History -->
                @if($order->shipment && $order->shipment->histories->count())
                <h6 class="fw-bold mb-3 mt-3">Riwayat Pengiriman</h6>
                <div class="position-relative ps-4">
                    @foreach($order->shipment->histories as $hist)
                    <div class="position-relative mb-3 pb-3 border-bottom border-light">
                        <div class="position-absolute start-0" style="margin-left:-12px;top:4px">
                            <div class="rounded-circle bg-primary" style="width:10px;height:10px"></div>
                        </div>
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="fw-semibold small">{{ $hist->description }}</div>
                                @if($hist->location)
                                <div class="text-muted small"><i class="bi bi-geo-alt me-1"></i>{{ $hist->location }}</div>
                                @endif
                            </div>
                            <div class="text-muted small text-end" style="flex-shrink:0;margin-left:10px">
                                {{ $hist->occurred_at->format('d M Y') }}<br>
                                {{ $hist->occurred_at->format('H:i') }}
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                @else
                <div class="text-center py-4 text-muted">
                    <i class="bi bi-clock fs-2"></i>
                    <p class="mt-2 small">Riwayat pengiriman belum tersedia.</p>
                </div>
                @endif
            </div>
        </div>

        <div class="col-md-5">
            <!-- Order Info -->
            <div class="card p-4 mb-4">
                <h6 class="fw-bold mb-3">Info Pesanan</h6>
                <div class="d-flex justify-content-between small mb-2">
                    <span class="text-muted">No. Pesanan</span>
                    <span class="fw-semibold">{{ $order->order_number }}</span>
                </div>
                <div class="d-flex justify-content-between small mb-2">
                    <span class="text-muted">Tanggal</span>
                    <span>{{ $order->created_at->format('d M Y') }}</span>
                </div>
                @if($order->shipped_at)
                <div class="d-flex justify-content-between small mb-2">
                    <span class="text-muted">Tgl Kirim</span>
                    <span>{{ $order->shipped_at->format('d M Y') }}</span>
                </div>
                @endif
                <div class="d-flex justify-content-between small mb-2">
                    <span class="text-muted">Kurir</span>
                    <span class="fw-semibold">{{ $order->shipping_courier ?? '-' }}</span>
                </div>
                @if($order->tracking_number)
                <div class="d-flex justify-content-between small mb-2">
                    <span class="text-muted">No. Resi</span>
                    <span class="fw-semibold text-primary">{{ $order->tracking_number }}</span>
                </div>
                @endif
            </div>

            <!-- Delivery Address -->
            <div class="card p-4 mb-4">
                <h6 class="fw-bold mb-3"><i class="bi bi-geo-alt me-2 text-danger"></i>Alamat Tujuan</h6>
                <p class="fw-semibold mb-1 small">{{ $order->shipping_name }}</p>
                <p class="text-muted small mb-0">
                    {{ $order->shipping_address }}<br>
                    {{ $order->shipping_city }}, {{ $order->shipping_province }}<br>
                    {{ $order->shipping_postal_code }}
                </p>
            </div>

            <!-- Items -->
            <div class="card p-4">
                <h6 class="fw-bold mb-3">Produk</h6>
                @foreach($order->items as $item)
                <div class="d-flex gap-2 align-items-center mb-2">
                    <img src="{{ $item->product_image ? asset('storage/'.$item->product_image) : asset('images/default-product.png') }}"
                         width="44" height="44" class="rounded" style="object-fit:cover">
                    <div class="flex-grow-1 small">
                        <div class="fw-semibold">{{ Str::limit($item->product_name,30) }}</div>
                        <div class="text-muted">x{{ $item->quantity }}</div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection

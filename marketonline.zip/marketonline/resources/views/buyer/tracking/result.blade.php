@extends('layouts.app')
@section('title','Hasil Tracking')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold mb-0">Hasil Tracking</h4>
                <a href="{{ route('buyer.tracking') }}" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-search me-1"></i>Lacak Lagi
                </a>
            </div>
            @include('buyer.tracking.show')
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')
@section('title','Lacak Pesanan')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card p-5 text-center mb-4">
                <i class="bi bi-truck fs-1 text-primary mb-3"></i>
                <h4 class="fw-bold mb-2">Lacak Pesanan</h4>
                <p class="text-muted mb-4">Masukkan nomor pesanan untuk melacak status pengiriman Anda</p>
                <form action="{{ route('buyer.tracking.search') }}" method="POST">
                    @csrf
                    <div class="input-group mb-3">
                        <input type="text" name="order_number" class="form-control form-control-lg @error('order_number') is-invalid @enderror"
                               placeholder="Contoh: MO-20240101-XXXX" value="{{ old('order_number') }}" required>
                        <button class="btn btn-primary px-4" type="submit">
                            <i class="bi bi-search me-1"></i>Lacak
                        </button>
                    </div>
                    @error('order_number')<div class="text-danger small">{{ $message }}</div>@enderror
                </form>
            </div>

            @auth
            <div class="card p-4">
                <h6 class="fw-bold mb-3">Pesanan yang Sedang Dikirim</h6>
                @php
                    $activeOrders = \App\Models\Order::with('shipment')
                        ->where('buyer_id', auth()->id())
                        ->whereIn('status',['shipped','processing','paid'])
                        ->latest()->limit(5)->get();
                @endphp
                @forelse($activeOrders as $order)
                <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                    <div>
                        <div class="fw-semibold small">#{{ $order->order_number }}</div>
                        <div class="text-muted small">{{ $order->created_at->format('d M Y') }}</div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-{{ $order->status_label['class'] }} small">{{ $order->status_label['label'] }}</span>
                        <a href="{{ route('buyer.tracking.show', $order) }}" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-eye"></i>
                        </a>
                    </div>
                </div>
                @empty
                <p class="text-muted small text-center py-3">Tidak ada pesanan aktif.</p>
                @endforelse
            </div>
            @endauth
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')
@section('title','Cari Produk')
@section('content')
<div class="container">
    <div class="row g-4">
        <!-- Filter Sidebar -->
        <div class="col-md-3">
            <div class="card p-4">
                <h6 class="fw-bold mb-3"><i class="bi bi-funnel me-2"></i>Filter</h6>
                <form action="{{ route('buyer.search') }}" method="GET">
                    <input type="hidden" name="q" value="{{ request('q') }}">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Kategori</label>
                        <select name="category_id" class="form-select form-select-sm">
                            <option value="">Semua Kategori</option>
                            @foreach($categories as $cat)
                                <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected':'' }}>
                                    {{ $cat->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Harga Min</label>
                        <input type="number" name="min_price" class="form-control form-control-sm"
                               value="{{ request('min_price') }}" placeholder="0">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Harga Max</label>
                        <input type="number" name="max_price" class="form-control form-control-sm"
                               value="{{ request('max_price') }}" placeholder="10000000">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Urutkan</label>
                        <select name="sort" class="form-select form-select-sm">
                            <option value="latest" {{ request('sort')=='latest'?'selected':'' }}>Terbaru</option>
                            <option value="price_asc" {{ request('sort')=='price_asc'?'selected':'' }}>Harga Terendah</option>
                            <option value="price_desc" {{ request('sort')=='price_desc'?'selected':'' }}>Harga Tertinggi</option>
                            <option value="popular" {{ request('sort')=='popular'?'selected':'' }}>Terpopuler</option>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-sm w-100">Terapkan Filter</button>
                    @if(request()->anyFilled(['category_id','min_price','max_price','sort']))
                        <a href="{{ route('buyer.search', ['q'=>request('q')]) }}" class="btn btn-outline-secondary btn-sm w-100 mt-2">Reset</a>
                    @endif
                </form>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <p class="text-muted mb-0">
                    @if(request('q'))
                        Hasil pencarian: <strong>"{{ request('q') }}"</strong> —
                    @endif
                    {{ $products->total() }} produk ditemukan
                </p>
            </div>

            @if($products->count())
            <div class="row g-4">
                @foreach($products as $product)
                <div class="col-6 col-lg-4">
                    <div class="card card-product h-100">
                        <a href="{{ route('buyer.product.detail', $product->slug) }}">
                            <img src="{{ $product->image_url }}" class="product-img" alt="{{ $product->name }}">
                        </a>
                        <div class="card-body p-3">
                            <p class="small text-muted mb-1">{{ $product->category?->name }}</p>
                            <a href="{{ route('buyer.product.detail', $product->slug) }}"
                               class="text-dark text-decoration-none fw-semibold" style="font-size:.9rem;">
                                {{ Str::limit($product->name, 50) }}
                            </a>
                            <div class="price-tag mt-2">{{ $product->formatted_price }}</div>
                            <p class="small text-muted mb-0 mt-1">
                                <i class="bi bi-shop"></i> {{ $product->seller->name }}
                            </p>
                            <p class="small text-muted mb-0">
                                <i class="bi bi-box"></i> Stok: {{ $product->stock }}
                            </p>
                        </div>
                        <div class="card-footer bg-white border-0 p-3 pt-0">
                            @auth
                                @if(!auth()->user()->hasRole('seller') && !auth()->user()->hasRole('admin'))
                                <form action="{{ route('buyer.cart.add') }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="product_id" value="{{ $product->id }}">
                                    <input type="hidden" name="quantity" value="1">
                                    <button class="btn btn-primary btn-sm w-100">
                                        <i class="bi bi-cart-plus"></i> Tambah
                                    </button>
                                </form>
                                @endif
                            @else
                                <a href="{{ route('login') }}" class="btn btn-outline-danger btn-sm w-100">Masuk dulu</a>
                            @endauth
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="mt-4">{{ $products->links() }}</div>
            @else
            <div class="text-center py-5 text-muted">
                <i class="bi bi-search fs-1"></i>
                <p class="mt-2">Produk tidak ditemukan.</p>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection

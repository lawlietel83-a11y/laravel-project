@extends('layouts.app')
@section('title', $product->name)
@section('content')
<div class="container">
    <!-- Breadcrumb -->
    <nav class="mb-3"><ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('buyer.home') }}">Beranda</a></li>
        <li class="breadcrumb-item"><a href="{{ route('buyer.search',['category_id'=>$product->category_id]) }}">{{ $product->category?->name }}</a></li>
        <li class="breadcrumb-item active">{{ Str::limit($product->name,40) }}</li>
    </ol></nav>

    <div class="row g-4 mb-5">
        <!-- Image -->
        <div class="col-md-5">
            <div class="card p-3">
                <img src="{{ $product->image_url }}" class="img-fluid rounded" alt="{{ $product->name }}" style="max-height:400px;object-fit:contain;">
            </div>
            @if($product->images)
            <div class="d-flex gap-2 mt-2">
                @foreach(array_slice($product->images, 0, 4) as $img)
                <img src="{{ asset('storage/'.$img) }}" class="rounded border" width="70" height="70" style="object-fit:cover;cursor:pointer;">
                @endforeach
            </div>
            @endif
        </div>

        <!-- Info -->
        <div class="col-md-7">
            <div class="card p-4">
                <span class="badge bg-secondary mb-2">{{ $product->category?->name }}</span>
                <h4 class="fw-bold mb-2">{{ $product->name }}</h4>
                <div class="d-flex align-items-center gap-3 mb-3">
                    <span class="fs-3 fw-bold text-danger">{{ $product->formatted_price }}</span>
                    <span class="badge {{ $product->stock > 0 ? 'bg-success':'bg-danger' }}">
                        {{ $product->stock > 0 ? 'Tersedia':'Habis' }}
                    </span>
                </div>
                <p class="text-muted small mb-3">Stok: <strong>{{ $product->stock }}</strong> | Berat: <strong>{{ $product->weight }}g</strong> | Kondisi: <strong>{{ $product->condition == 'new' ? 'Baru':'Bekas' }}</strong></p>

                @if($product->stock > 0)
                @auth
                    @if(!auth()->user()->hasRole('seller') && !auth()->user()->hasRole('admin'))
                    <form action="{{ route('buyer.cart.add') }}" method="POST" class="d-flex gap-3 mb-3">
                        @csrf
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        <div class="input-group" style="width:130px">
                            <button type="button" class="btn btn-outline-secondary" onclick="changeQty(-1)">-</button>
                            <input type="number" name="quantity" id="qty" class="form-control text-center" value="1" min="1" max="{{ $product->stock }}">
                            <button type="button" class="btn btn-outline-secondary" onclick="changeQty(1)">+</button>
                        </div>
                        <button type="submit" class="btn btn-primary flex-grow-1">
                            <i class="bi bi-cart-plus me-2"></i>Tambah ke Keranjang
                        </button>
                    </form>
                    @endif
                @else
                    <a href="{{ route('login') }}" class="btn btn-primary w-100 mb-3">
                        <i class="bi bi-lock me-2"></i>Masuk untuk membeli
                    </a>
                @endauth
                @endif

                <!-- Seller Card -->
                <div class="border rounded p-3 mt-2">
                    <div class="d-flex align-items-center gap-3">
                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white fw-bold"
                             style="width:44px;height:44px;font-size:1.2rem;">
                            {{ strtoupper(substr($product->seller->name,0,1)) }}
                        </div>
                        <div>
                            <div class="fw-semibold">{{ $product->seller->shopProfile?->shop_name ?? $product->seller->name }}</div>
                            <small class="text-muted">{{ $product->seller->shopProfile?->city ?? '' }}</small>
                        </div>
                        @if($product->seller->shopProfile?->is_verified)
                            <span class="badge bg-success ms-auto"><i class="bi bi-check-circle me-1"></i>Terverifikasi</span>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Description -->
    <div class="card p-4 mb-4">
        <h5 class="fw-bold mb-3">Deskripsi Produk</h5>
        <p class="text-muted" style="white-space:pre-line">{{ $product->description }}</p>
    </div>

    <!-- Reviews -->
    <div class="card p-4 mb-5">
        <h5 class="fw-bold mb-3">Ulasan Pembeli ({{ $product->reviews->count() }})</h5>
        @forelse($product->reviews->take(5) as $review)
        <div class="border-bottom pb-3 mb-3">
            <div class="d-flex gap-3">
                <div class="bg-secondary rounded-circle text-white d-flex align-items-center justify-content-center"
                     style="width:38px;height:38px;flex-shrink:0">
                    {{ strtoupper(substr($review->user->name,0,1)) }}
                </div>
                <div>
                    <div class="fw-semibold">{{ $review->user->name }}</div>
                    <div class="text-warning small mb-1">
                        @for($i=1;$i<=5;$i++)
                            <i class="bi bi-star{{ $i<=$review->rating?'-fill':'' }}"></i>
                        @endfor
                    </div>
                    <p class="mb-0 small text-muted">{{ $review->comment }}</p>
                </div>
            </div>
        </div>
        @empty
        <p class="text-muted small">Belum ada ulasan untuk produk ini.</p>
        @endforelse
    </div>

    <!-- Related Products -->
    @if($related->count())
    <h5 class="section-title mb-4">Produk Serupa</h5>
    <div class="row g-4">
        @foreach($related as $rel)
        <div class="col-6 col-md-4 col-lg-2">
            <div class="card card-product h-100">
                <a href="{{ route('buyer.product.detail', $rel->slug) }}">
                    <img src="{{ $rel->image_url }}" class="product-img" alt="{{ $rel->name }}" style="height:140px;">
                </a>
                <div class="card-body p-2">
                    <p class="small fw-semibold mb-1">{{ Str::limit($rel->name,30) }}</p>
                    <p class="price-tag small mb-0">{{ $rel->formatted_price }}</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    @endif
</div>
@push('scripts')
<script>
function changeQty(d){
    const el=document.getElementById('qty');
    const v=parseInt(el.value)+d;
    if(v>=1 && v<={{ $product->stock }}) el.value=v;
}
</script>
@endpush
@endsection

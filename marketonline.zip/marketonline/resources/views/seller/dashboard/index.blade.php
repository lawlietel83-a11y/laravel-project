@extends('layouts.seller')
@section('title','Dashboard')
@section('page-title','Dashboard Seller')
@section('content')
<!-- Stats -->
<div class="row g-4 mb-4">
    @foreach([
        ['label'=>'Total Produk',    'value'=>$stats['total_products'],    'icon'=>'bi-box-seam',    'color'=>'#1565c0'],
        ['label'=>'Produk Aktif',    'value'=>$stats['active_products'],   'icon'=>'bi-check-circle','color'=>'#2e7d32'],
        ['label'=>'Total Pesanan',   'value'=>$stats['total_orders'],      'icon'=>'bi-receipt',     'color'=>'#6a1b9a'],
        ['label'=>'Menunggu Proses', 'value'=>$stats['pending_orders'],    'icon'=>'bi-hourglass',   'color'=>'#e65100'],
        ['label'=>'Sedang Diproses', 'value'=>$stats['processing_orders'], 'icon'=>'bi-gear',        'color'=>'#f57f17'],
        ['label'=>'Total Pendapatan','value'=>'Rp '.number_format($stats['total_revenue'],0,',','.'), 'icon'=>'bi-cash-stack','color'=>'#c62828'],
    ] as $s)
    <div class="col-6 col-md-4 col-lg-2">
        <div class="card p-3 h-100" style="border-left:4px solid {{ $s['color'] }}">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <span class="small text-muted">{{ $s['label'] }}</span>
                <i class="bi {{ $s['icon'] }}" style="color:{{ $s['color'] }};font-size:1.2rem"></i>
            </div>
            <h4 class="fw-bold mb-0" style="color:{{ $s['color'] }}">{{ $s['value'] }}</h4>
        </div>
    </div>
    @endforeach
</div>

<div class="row g-4">
    <!-- Recent Orders -->
    <div class="col-md-8">
        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="fw-bold mb-0">Pesanan Terbaru</h6>
                <a href="{{ route('seller.orders.index') }}" class="btn btn-outline-primary btn-sm">Semua Pesanan</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr><th>No. Pesanan</th><th>Pembeli</th><th>Total</th><th>Status</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        @forelse($recentOrders as $order)
                        <tr>
                            <td class="small fw-semibold">#{{ $order->order_number }}</td>
                            <td class="small">{{ $order->buyer->name }}</td>
                            <td class="small fw-bold text-danger">{{ $order->formatted_total }}</td>
                            <td><span class="badge bg-{{ $order->status_label['class'] }}">{{ $order->status_label['label'] }}</span></td>
                            <td>
                                <a href="{{ route('seller.orders.show',$order) }}" class="btn btn-outline-primary btn-sm">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="5" class="text-center py-4 text-muted">Belum ada pesanan.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Low Stock + Quick Actions -->
    <div class="col-md-4">
        @if($lowStockProducts->count())
        <div class="card p-4 mb-4 border-warning">
            <h6 class="fw-bold mb-3 text-warning"><i class="bi bi-exclamation-triangle me-2"></i>Stok Hampir Habis</h6>
            @foreach($lowStockProducts as $p)
            <div class="d-flex justify-content-between align-items-center mb-2 small">
                <span class="fw-semibold">{{ Str::limit($p->name,25) }}</span>
                <span class="badge bg-warning text-dark">{{ $p->stock }} sisa</span>
            </div>
            @endforeach
        </div>
        @endif
        <div class="card p-4">
            <h6 class="fw-bold mb-3">Aksi Cepat</h6>
            <div class="d-grid gap-2">
                <a href="{{ route('seller.products.create') }}" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-circle me-2"></i>Tambah Produk Baru
                </a>
                <a href="{{ route('seller.orders.index',['status'=>'paid']) }}" class="btn btn-outline-success btn-sm">
                    <i class="bi bi-receipt me-2"></i>Pesanan Siap Proses
                </a>
                <a href="{{ route('seller.orders.index',['status'=>'processing']) }}" class="btn btn-outline-warning btn-sm">
                    <i class="bi bi-truck me-2"></i>Pesanan Siap Kirim
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.seller')
@section('title','Produk Saya')
@section('page-title','Produk Saya')
@section('content')
<div class="card p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0">Daftar Produk</h6>
        <a href="{{ route('seller.products.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle me-2"></i>Tambah Produk
        </a>
    </div>
    <form class="row g-2 mb-4" method="GET">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control form-control-sm"
                   placeholder="Cari produk…" value="{{ request('search') }}">
        </div>
        <div class="col-md-3">
            <select name="category_id" class="form-select form-select-sm">
                <option value="">Semua Kategori</option>
                @foreach($categories as $cat)
                <option value="{{ $cat->id }}" {{ request('category_id')==$cat->id?'selected':'' }}>{{ $cat->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-2">
            <select name="status" class="form-select form-select-sm">
                <option value="">Semua Status</option>
                <option value="active" {{ request('status')==='active'?'selected':'' }}>Aktif</option>
                <option value="inactive" {{ request('status')==='inactive'?'selected':'' }}>Nonaktif</option>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary btn-sm">Filter</button>
        </div>
    </form>

    <div class="row g-4">
        @forelse($products as $product)
        <div class="col-md-4 col-lg-3">
            <div class="card h-100">
                <img src="{{ $product->image_url }}" class="card-img-top" style="height:160px;object-fit:cover;" alt="">
                <div class="card-body p-3">
                    <p class="small text-muted mb-1">{{ $product->category->name }}</p>
                    <h6 class="fw-semibold mb-1" style="font-size:.9rem">{{ Str::limit($product->name,40) }}</h6>
                    <p class="text-danger fw-bold mb-1">{{ $product->formatted_price }}</p>
                    <div class="d-flex justify-content-between small text-muted">
                        <span>Stok: <strong class="{{ $product->stock<=5?'text-danger':'' }}">{{ $product->stock }}</strong></span>
                        <span class="badge {{ $product->is_active?'bg-success':'bg-secondary' }}">
                            {{ $product->is_active?'Aktif':'Nonaktif' }}
                        </span>
                    </div>
                </div>
                <div class="card-footer bg-white p-2 d-flex gap-1">
                    <a href="{{ route('seller.products.edit',$product) }}" class="btn btn-outline-primary btn-sm flex-fill">
                        <i class="bi bi-pencil me-1"></i>Edit
                    </a>
                    <form action="{{ route('seller.products.destroy',$product) }}" method="POST"
                          onsubmit="return confirm('Hapus produk ini?')">
                        @csrf @method('DELETE')
                        <button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash"></i></button>
                    </form>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12 text-center py-5">
            <i class="bi bi-box-seam fs-1 text-muted"></i>
            <p class="text-muted mt-3">Belum ada produk. Mulai tambahkan produk Anda!</p>
            <a href="{{ route('seller.products.create') }}" class="btn btn-primary px-5">Tambah Produk Pertama</a>
        </div>
        @endforelse
    </div>
    <div class="mt-4">{{ $products->links() }}</div>
</div>
@endsection

@extends('layouts.seller')
@section('title', isset($product) ? 'Edit Produk' : 'Tambah Produk')
@section('page-title', isset($product) ? 'Edit Produk' : 'Tambah Produk')
@section('content')
<div class="row justify-content-center">
    <div class="col-md-9">
        <div class="card p-5">
            <h5 class="fw-bold mb-4">{{ isset($product) ? 'Edit Produk' : 'Tambah Produk Baru' }}</h5>
            <form action="{{ isset($product) ? route('seller.products.update',$product) : route('seller.products.store') }}"
                  method="POST" enctype="multipart/form-data">
                @csrf
                @if(isset($product)) @method('PUT') @endif

                <div class="row g-4">
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Produk <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                                   value="{{ old('name', $product->name ?? '') }}" required placeholder="Nama produk Anda">
                            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Kategori <span class="text-danger">*</span></label>
                            <select name="category_id" class="form-select @error('category_id') is-invalid @enderror" required>
                                <option value="">-- Pilih Kategori --</option>
                                @foreach($categories as $cat)
                                <option value="{{ $cat->id }}" {{ old('category_id', $product->category_id ?? '') == $cat->id ? 'selected':'' }}>
                                    {{ $cat->name }}
                                </option>
                                @endforeach
                            </select>
                            @error('category_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Deskripsi <span class="text-danger">*</span></label>
                            <textarea name="description" rows="5" class="form-control @error('description') is-invalid @enderror"
                                      required placeholder="Deskripsi lengkap produk Anda…">{{ old('description', $product->description ?? '') }}</textarea>
                            @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Harga (Rp) <span class="text-danger">*</span></label>
                                <input type="number" name="price" class="form-control @error('price') is-invalid @enderror"
                                       value="{{ old('price', $product->price ?? '') }}" min="0" required>
                                @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Stok <span class="text-danger">*</span></label>
                                <input type="number" name="stock" class="form-control @error('stock') is-invalid @enderror"
                                       value="{{ old('stock', $product->stock ?? '') }}" min="0" required>
                                @error('stock')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Berat (gram) <span class="text-danger">*</span></label>
                                <input type="number" name="weight" class="form-control @error('weight') is-invalid @enderror"
                                       value="{{ old('weight', $product->weight ?? '') }}" min="0" required>
                                @error('weight')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                        </div>

                        <div class="mt-3">
                            <label class="form-label fw-semibold">Kondisi</label>
                            <div class="d-flex gap-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="condition" value="new" id="condNew"
                                           {{ old('condition', $product->condition ?? 'new') === 'new' ? 'checked':'' }}>
                                    <label class="form-check-label" for="condNew">Baru</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="condition" value="used" id="condUsed"
                                           {{ old('condition', $product->condition ?? '') === 'used' ? 'checked':'' }}>
                                    <label class="form-check-label" for="condUsed">Bekas</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Foto Utama {{ isset($product)?'':'<span class="text-danger">*</span>' }}</label>
                            @if(isset($product) && $product->image)
                            <div class="mb-2">
                                <img src="{{ $product->image_url }}" height="120" class="rounded border img-fluid" alt="">
                            </div>
                            @endif
                            <input type="file" name="image" class="form-control @error('image') is-invalid @enderror"
                                   accept="image/*" {{ isset($product)?'':'required' }} id="imageInput">
                            @error('image')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            <div id="imagePreview" class="mt-2"></div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Foto Tambahan (maks 4)</label>
                            <input type="file" name="images[]" class="form-control" accept="image/*" multiple>
                        </div>

                        <div class="form-check form-switch mt-3">
                            <input class="form-check-input" type="checkbox" name="is_active" value="1" id="isActive"
                                   {{ old('is_active', $product->is_active ?? true) ? 'checked':'' }}>
                            <label class="form-check-label fw-semibold" for="isActive">Produk Aktif / Dipajang</label>
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2 mt-4 border-top pt-4">
                    <button type="submit" class="btn btn-primary px-5">
                        <i class="bi bi-check-lg me-2"></i>{{ isset($product) ? 'Simpan Perubahan' : 'Tambah Produk' }}
                    </button>
                    <a href="{{ route('seller.products.index') }}" class="btn btn-outline-secondary px-4">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
@push('scripts')
<script>
document.getElementById('imageInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(ev) {
        document.getElementById('imagePreview').innerHTML =
            '<img src="'+ev.target.result+'" class="rounded border" style="max-height:120px;">';
    };
    reader.readAsDataURL(file);
});
</script>
@endpush
@endsection

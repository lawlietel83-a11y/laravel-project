@extends('layouts.seller')
@section('title','Detail Pesanan')
@section('page-title','Detail Pesanan')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="fw-bold mb-1">#{{ $order->order_number }}</h5>
        <span class="badge bg-{{ $order->status_label['class'] }} fs-6">{{ $order->status_label['label'] }}</span>
    </div>
    <a href="{{ route('seller.orders.index') }}" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i>Kembali
    </a>
</div>

<div class="row g-4">
    <div class="col-md-8">
        <!-- Items -->
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3">Produk Dipesan</h6>
            @foreach($order->items as $item)
            <div class="d-flex gap-3 align-items-center border-bottom pb-3 mb-3">
                <img src="{{ $item->product_image ? asset('storage/'.$item->product_image) : asset('images/default-product.png') }}"
                     width="64" height="64" class="rounded" style="object-fit:cover;flex-shrink:0">
                <div class="flex-grow-1">
                    <div class="fw-semibold">{{ $item->product_name }}</div>
                    <div class="text-muted small">{{ $item->quantity }} x {{ $item->formatted_price }}</div>
                    @if($item->notes)
                    <div class="text-muted small"><i class="bi bi-chat-left-text me-1"></i>{{ $item->notes }}</div>
                    @endif
                </div>
                <div class="fw-bold text-danger">{{ $item->formatted_subtotal }}</div>
            </div>
            @endforeach
            <div class="border-top pt-3">
                <div class="d-flex justify-content-between small mb-1">
                    <span class="text-muted">Subtotal Produk</span>
                    <span>Rp {{ number_format($order->subtotal,0,',','.') }}</span>
                </div>
                <div class="d-flex justify-content-between small mb-1">
                    <span class="text-muted">Ongkos Kirim</span>
                    <span>Rp {{ number_format($order->shipping_cost,0,',','.') }}</span>
                </div>
                <div class="d-flex justify-content-between fw-bold mt-2">
                    <span>Total</span>
                    <span class="text-danger">{{ $order->formatted_total }}</span>
                </div>
            </div>
        </div>

        <!-- Shipment History -->
        @if($order->shipment)
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3"><i class="bi bi-truck me-2"></i>Info Pengiriman</h6>
            <div class="row g-2 mb-3">
                <div class="col-md-6 small"><span class="text-muted">Kurir</span><p class="fw-semibold mb-0">{{ strtoupper($order->shipment->courier) }}</p></div>
                <div class="col-md-6 small"><span class="text-muted">No. Resi</span><p class="fw-semibold mb-0 text-primary">{{ $order->shipment->tracking_number ?? '-' }}</p></div>
                <div class="col-md-6 small"><span class="text-muted">Status</span>
                    <p class="mb-0"><span class="badge bg-{{ $order->shipment->status_label['class'] }}">{{ $order->shipment->status_label['label'] }}</span></p>
                </div>
                <div class="col-md-6 small"><span class="text-muted">Tanggal Kirim</span>
                    <p class="fw-semibold mb-0">{{ $order->shipment->shipped_at?->format('d M Y H:i') ?? '-' }}</p>
                </div>
            </div>
            @if($order->shipment->histories->count())
            <hr>
            <h6 class="fw-semibold mb-3 small">Riwayat Pengiriman</h6>
            @foreach($order->shipment->histories as $hist)
            <div class="d-flex gap-3 mb-2 small">
                <div class="text-muted" style="min-width:120px">{{ $hist->occurred_at->format('d M Y H:i') }}</div>
                <div>
                    <div class="fw-semibold">{{ $hist->description }}</div>
                    @if($hist->location)<div class="text-muted"><i class="bi bi-geo-alt me-1"></i>{{ $hist->location }}</div>@endif
                </div>
            </div>
            @endforeach
            @endif
        </div>
        @endif
    </div>

    <div class="col-md-4">
        <!-- Buyer Info -->
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3"><i class="bi bi-person me-2"></i>Info Pembeli</h6>
            <p class="fw-semibold mb-1 small">{{ $order->buyer->name }}</p>
            <p class="small mb-1 text-muted">{{ $order->buyer->email }}</p>
            <p class="small mb-0 text-muted">{{ $order->buyer->phone ?? '-' }}</p>
        </div>

        <!-- Shipping Address -->
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3"><i class="bi bi-geo-alt me-2 text-danger"></i>Alamat Pengiriman</h6>
            <p class="fw-semibold mb-1 small">{{ $order->shipping_name }}</p>
            <p class="mb-1 small">{{ $order->shipping_phone }}</p>
            <p class="small text-muted mb-0">
                {{ $order->shipping_address }},<br>
                {{ $order->shipping_city }}, {{ $order->shipping_province }} {{ $order->shipping_postal_code }}
            </p>
            <p class="small mt-2 mb-0 fw-semibold">
                <i class="bi bi-truck me-1 text-muted"></i>{{ strtoupper($order->shipping_courier ?? '-') }}
            </p>
        </div>

        <!-- Actions -->
        <div class="card p-4">
            <h6 class="fw-bold mb-3">Aksi</h6>

            @if($order->status === 'paid')
            <form action="{{ route('seller.orders.process', $order) }}" method="POST" class="mb-2">
                @csrf
                <button class="btn btn-success w-100" onclick="return confirm('Proses pesanan ini?')">
                    <i class="bi bi-gear me-2"></i>Proses Pesanan
                </button>
            </form>
            @endif

            @if($order->status === 'processing')
            <button class="btn btn-primary w-100 mb-2" data-bs-toggle="modal" data-bs-target="#shipModal">
                <i class="bi bi-truck me-2"></i>Input Resi & Kirim
            </button>
            @endif

            @if(in_array($order->status, ['pending','paid','processing']))
            <p class="text-muted small text-center mt-1 mb-0">
                <i class="bi bi-clock me-1"></i>Menunggu tindakan Anda
            </p>
            @endif

            @if($order->status === 'shipped')
            <div class="alert alert-info small mb-0">
                <i class="bi bi-truck me-2"></i>Pesanan sedang dalam pengiriman.
            </div>
            @endif

            @if(in_array($order->status, ['completed','delivered']))
            <div class="alert alert-success small mb-0">
                <i class="bi bi-check-circle me-2"></i>Pesanan telah selesai.
            </div>
            @endif
        </div>
    </div>
</div>

<!-- Ship Modal -->
@if($order->status === 'processing')
<div class="modal fade" id="shipModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Input Nomor Resi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('seller.orders.ship', $order) }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Kurir</label>
                        <select name="courier" class="form-select" required>
                            @foreach(['JNE','J&T Express','SiCepat','Anteraja','Pos Indonesia','Wahana','Ninja Express'] as $c)
                            <option value="{{ $c }}" {{ $order->shipping_courier === $c ? 'selected':'' }}>{{ $c }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Layanan</label>
                        <input type="text" name="service" class="form-control" placeholder="Contoh: Reguler, YES, OKE">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nomor Resi <span class="text-danger">*</span></label>
                        <input type="text" name="tracking_number" class="form-control @error('tracking_number') is-invalid @enderror"
                               placeholder="Masukkan nomor resi" required>
                        @error('tracking_number')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-truck me-2"></i>Konfirmasi Pengiriman
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif
@endsection

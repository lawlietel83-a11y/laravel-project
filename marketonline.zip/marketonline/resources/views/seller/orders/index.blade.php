@extends('layouts.seller')
@section('title','Pesanan')
@section('page-title','Manajemen Pesanan')
@section('content')
<div class="card p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0">Daftar Pesanan Masuk</h6>
    </div>

    <!-- Status Tabs -->
    <ul class="nav nav-pills mb-4 gap-1 flex-wrap">
        @foreach(['' => 'Semua', 'pending' => 'Pending', 'paid' => 'Dibayar', 'processing' => 'Diproses', 'shipped' => 'Dikirim', 'completed' => 'Selesai', 'cancelled' => 'Batal'] as $val => $label)
        <li class="nav-item">
            <a class="nav-link py-1 px-3 {{ request('status') === $val ? 'active' : '' }}"
               href="{{ route('seller.orders.index', array_merge(request()->query(), ['status' => $val])) }}">
                {{ $label }}
            </a>
        </li>
        @endforeach
    </ul>

    <form class="row g-2 mb-4" method="GET">
        <input type="hidden" name="status" value="{{ request('status') }}">
        <div class="col-md-6">
            <input type="text" name="search" class="form-control form-control-sm"
                   placeholder="Cari nomor pesanan…" value="{{ request('search') }}">
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary btn-sm">Cari</button>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>No. Pesanan</th>
                    <th>Pembeli</th>
                    <th>Produk</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($orders as $order)
                <tr>
                    <td class="fw-semibold small">#{{ $order->order_number }}</td>
                    <td class="small">{{ $order->buyer->name }}</td>
                    <td class="small">{{ $order->items->count() }} item</td>
                    <td class="fw-bold text-danger small">{{ $order->formatted_total }}</td>
                    <td>
                        <span class="badge bg-{{ $order->status_label['class'] }}">
                            {{ $order->status_label['label'] }}
                        </span>
                    </td>
                    <td class="text-muted small">{{ $order->created_at->format('d M Y') }}</td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="{{ route('seller.orders.show', $order) }}" class="btn btn-outline-primary btn-sm" title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            @if($order->status === 'paid')
                            <form action="{{ route('seller.orders.process', $order) }}" method="POST">
                                @csrf
                                <button class="btn btn-success btn-sm" title="Proses">
                                    <i class="bi bi-gear"></i>
                                </button>
                            </form>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="text-center py-5 text-muted">
                        <i class="bi bi-receipt fs-2 d-block mb-2"></i>
                        Tidak ada pesanan ditemukan.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $orders->links() }}
</div>
@endsection

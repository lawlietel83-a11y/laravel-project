<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Admin;
use App\Http\Controllers\Seller;
use App\Http\Controllers\Buyer;
use Illuminate\Support\Facades\Route;

// ─── Public ──────────────────────────────────────────────────
Route::get('/', [Buyer\HomeController::class, 'index'])->name('buyer.home');
Route::get('/search', [Buyer\HomeController::class, 'search'])->name('buyer.search');
Route::get('/produk/{product:slug}', [Buyer\HomeController::class, 'productDetail'])->name('buyer.product.detail');

// ─── Auth ─────────────────────────────────────────────────────
Route::middleware('guest')->group(function () {
    Route::get('/login',    [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login',   [LoginController::class, 'login']);
    Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register',[RegisterController::class, 'register']);
});
Route::post('/logout', [LoginController::class, 'logout'])->name('logout')->middleware('auth');

// ─── Buyer ────────────────────────────────────────────────────
Route::middleware(['auth', 'check.role:buyer,admin'])->prefix('buyer')->name('buyer.')->group(function () {
    // Cart
    Route::get('/cart',                   [Buyer\CartController::class, 'index'])->name('cart');
    Route::post('/cart/add',              [Buyer\CartController::class, 'add'])->name('cart.add');
    Route::patch('/cart/{cart}',          [Buyer\CartController::class, 'update'])->name('cart.update');
    Route::delete('/cart/{cart}',         [Buyer\CartController::class, 'remove'])->name('cart.remove');
    Route::delete('/cart',                [Buyer\CartController::class, 'clear'])->name('cart.clear');

    // Checkout & Orders
    Route::get('/checkout',               [Buyer\OrderController::class, 'checkout'])->name('checkout');
    Route::post('/orders',                [Buyer\OrderController::class, 'placeOrder'])->name('orders.place');
    Route::get('/orders',                 [Buyer\OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/{order}',         [Buyer\OrderController::class, 'show'])->name('orders.show');
    Route::post('/orders/{order}/confirm',[Buyer\OrderController::class, 'confirmReceived'])->name('orders.confirm');
    Route::post('/orders/{order}/cancel', [Buyer\OrderController::class, 'cancel'])->name('orders.cancel');

    // Payment
    Route::get('/orders/{order}/payment',     [Buyer\PaymentController::class, 'show'])->name('orders.payment');
    Route::post('/orders/{order}/pay',        [Buyer\PaymentController::class, 'confirm'])->name('orders.pay');

    // Tracking
    Route::get('/tracking',               [Buyer\TrackingController::class, 'index'])->name('tracking');
    Route::post('/tracking',              [Buyer\TrackingController::class, 'track'])->name('tracking.search');
    Route::get('/tracking/{order}',       [Buyer\TrackingController::class, 'show'])->name('tracking.show');
});

// Payment webhook (public, no auth)
Route::post('/payment/notification', [Buyer\PaymentController::class, 'notification'])->name('payment.notification');

// ─── Seller ───────────────────────────────────────────────────
Route::middleware(['auth', 'check.role:seller'])->prefix('seller')->name('seller.')->group(function () {
    Route::get('/dashboard', [Seller\DashboardController::class, 'index'])->name('dashboard');

    // Products CRUD
    Route::resource('products', Seller\ProductController::class);

    // Orders
    Route::get('/orders',               [Seller\OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/{order}',       [Seller\OrderController::class, 'show'])->name('orders.show');
    Route::post('/orders/{order}/process', [Seller\OrderController::class, 'process'])->name('orders.process');
    Route::post('/orders/{order}/ship',    [Seller\OrderController::class, 'ship'])->name('orders.ship');
});

// ─── Admin ────────────────────────────────────────────────────
Route::middleware(['auth', 'check.role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [Admin\DashboardController::class, 'index'])->name('dashboard');

    // Users CRUD
    Route::resource('users', Admin\UserController::class);
    Route::patch('/users/{user}/toggle-status', [Admin\UserController::class, 'toggleStatus'])->name('users.toggle-status');

    // Categories CRUD
    Route::resource('categories', Admin\CategoryController::class);

    // Products
    Route::get('/products',                    [Admin\ProductController::class, 'index'])->name('products.index');
    Route::get('/products/{product}',          [Admin\ProductController::class, 'show'])->name('products.show');
    Route::patch('/products/{product}/toggle', [Admin\ProductController::class, 'toggleStatus'])->name('products.toggle');
    Route::delete('/products/{product}',       [Admin\ProductController::class, 'destroy'])->name('products.destroy');
    Route::post('/products/{id}/restore',      [Admin\ProductController::class, 'restore'])->name('products.restore');

    // Orders
    Route::get('/orders',                          [Admin\OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/{order}',                  [Admin\OrderController::class, 'show'])->name('orders.show');
    Route::patch('/orders/{order}/status',         [Admin\OrderController::class, 'updateStatus'])->name('orders.update-status');
});

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('shipments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->onDelete('cascade');
            $table->string('courier', 50);
            $table->string('service', 100)->nullable();
            $table->string('tracking_number', 100)->nullable();
            $table->enum('status', [
                'pending','picked_up','in_transit','out_for_delivery','delivered','failed','returned'
            ])->default('pending');
            $table->string('origin_city', 100)->nullable();
            $table->string('destination_city', 100)->nullable();
            $table->decimal('weight', 8, 2)->nullable();
            $table->decimal('cost', 15, 2)->nullable();
            $table->unsignedInteger('estimated_days')->nullable();
            $table->timestamp('shipped_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->json('raw_tracking')->nullable();
            $table->timestamps();
        });

        Schema::create('shipment_histories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('shipment_id')->constrained('shipments')->onDelete('cascade');
            $table->string('status', 50);
            $table->text('description');
            $table->string('location', 200)->nullable();
            $table->timestamp('occurred_at');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('shipment_histories');
        Schema::dropIfExists('shipments');
    }
};

<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\ShopProfile;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        $admin = User::firstOrCreate(['email' => 'admin@marketonline.com'], [
            'name'      => 'Administrator',
            'password'  => Hash::make('password'),
            'phone'     => '08100000001',
            'address'   => 'Jl. Admin No.1',
            'city'      => 'Jakarta',
            'province'  => 'DKI Jakarta',
            'postal_code'=> '10110',
            'is_active' => true,
        ]);
        $admin->assignRole('admin');

        // Seller
        $seller = User::firstOrCreate(['email' => 'seller@marketonline.com'], [
            'name'      => 'Toko Contoh',
            'password'  => Hash::make('password'),
            'phone'     => '08100000002',
            'address'   => 'Jl. Seller No.2',
            'city'      => 'Bandung',
            'province'  => 'Jawa Barat',
            'postal_code'=> '40111',
            'is_active' => true,
        ]);
        $seller->assignRole('seller');
        ShopProfile::firstOrCreate(['seller_id' => $seller->id], [
            'shop_name'   => 'Toko Contoh Official',
            'slug'        => 'toko-contoh-official',
            'description' => 'Toko resmi produk berkualitas tinggi.',
            'city'        => 'Bandung',
            'province'    => 'Jawa Barat',
            'address'     => 'Jl. Seller No.2',
            'phone'       => '08100000002',
            'is_verified' => true,
        ]);

        // Buyer
        $buyer = User::firstOrCreate(['email' => 'buyer@marketonline.com'], [
            'name'      => 'Pembeli Demo',
            'password'  => Hash::make('password'),
            'phone'     => '08100000003',
            'address'   => 'Jl. Buyer No.3',
            'city'      => 'Surabaya',
            'province'  => 'Jawa Timur',
            'postal_code'=> '60111',
            'is_active' => true,
        ]);
        $buyer->assignRole('buyer');
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        $permissions = [
            // Product
            'product.view','product.create','product.edit','product.delete',
            // Order
            'order.view','order.manage',
            // User
            'user.view','user.create','user.edit','user.delete',
            // Category
            'category.view','category.create','category.edit','category.delete',
            // Report
            'report.view',
            // Payment
            'payment.view','payment.manage',
        ];

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(['name' => $perm, 'guard_name' => 'web']);
        }

        // Admin role
        $admin = Role::firstOrCreate(['name' => 'admin', 'guard_name' => 'web']);
        $admin->syncPermissions(Permission::all());

        // Seller role
        $seller = Role::firstOrCreate(['name' => 'seller', 'guard_name' => 'web']);
        $seller->syncPermissions([
            'product.view','product.create','product.edit','product.delete',
            'order.view','order.manage','payment.view',
        ]);

        // Buyer role
        $buyer = Role::firstOrCreate(['name' => 'buyer', 'guard_name' => 'web']);
        $buyer->syncPermissions([
            'product.view','order.view','payment.view',
        ]);
    }
}

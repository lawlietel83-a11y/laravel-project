<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Elektronik',       'description' => 'Produk elektronik & gadget'],
            ['name' => 'Fashion Pria',     'description' => 'Pakaian & aksesoris pria'],
            ['name' => 'Fashion Wanita',   'description' => 'Pakaian & aksesoris wanita'],
            ['name' => 'Makanan & Minuman','description' => 'Produk makanan dan minuman'],
            ['name' => 'Rumah & Taman',    'description' => 'Perlengkapan rumah dan taman'],
            ['name' => 'Olahraga',         'description' => 'Peralatan & pakaian olahraga'],
            ['name' => 'Buku',             'description' => 'Buku, majalah & alat tulis'],
            ['name' => 'Kesehatan',        'description' => 'Produk kesehatan & kecantikan'],
        ];

        foreach ($categories as $cat) {
            Category::firstOrCreate(
                ['slug' => Str::slug($cat['name'])],
                array_merge($cat, ['is_active' => true])
            );
        }
    }
}

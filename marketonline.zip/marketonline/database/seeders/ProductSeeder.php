<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $seller = User::whereHas('roles', fn($q) => $q->where('name', 'seller'))->first();
        if (!$seller) return;

        $electronics = Category::where('slug', 'elektronik')->first();
        $fashion     = Category::where('slug', 'fashion-pria')->first();
        $food        = Category::where('slug', 'makanan-minuman')->first();

        $products = [
            [
                'category_id' => $electronics?->id ?? 1,
                'name'        => 'Smartphone XYZ Pro',
                'description' => 'Smartphone terbaru dengan fitur canggih, kamera 108MP, baterai 5000mAh.',
                'price'       => 3500000,
                'stock'       => 50,
                'weight'      => 250,
                'condition'   => 'new',
            ],
            [
                'category_id' => $electronics?->id ?? 1,
                'name'        => 'Laptop UltraBook 14"',
                'description' => 'Laptop tipis bertenaga tinggi, Intel i7 Gen 12, RAM 16GB, SSD 512GB.',
                'price'       => 12000000,
                'stock'       => 20,
                'weight'      => 1500,
                'condition'   => 'new',
            ],
            [
                'category_id' => $fashion?->id ?? 2,
                'name'        => 'Kaos Polo Premium',
                'description' => 'Kaos polo bahan katun premium, nyaman dipakai sehari-hari.',
                'price'       => 150000,
                'stock'       => 100,
                'weight'      => 200,
                'condition'   => 'new',
            ],
            [
                'category_id' => $food?->id ?? 4,
                'name'        => 'Kopi Arabika Gayo 250gr',
                'description' => 'Kopi arabika pilihan dari pegunungan Gayo, Aceh.',
                'price'       => 85000,
                'stock'       => 200,
                'weight'      => 300,
                'condition'   => 'new',
            ],
            [
                'category_id' => $electronics?->id ?? 1,
                'name'        => 'Earbuds TWS Wireless',
                'description' => 'Earbuds true wireless dengan noise cancellation, suara jernih.',
                'price'       => 450000,
                'stock'       => 75,
                'weight'      => 50,
                'condition'   => 'new',
            ],
        ];

        foreach ($products as $p) {
            $slug = Str::slug($p['name']);
            Product::firstOrCreate(['slug' => $slug], array_merge($p, [
                'seller_id' => $seller->id,
                'slug'      => $slug,
                'is_active' => true,
                'sku'       => strtoupper(Str::random(8)),
            ]));
        }
    }
}

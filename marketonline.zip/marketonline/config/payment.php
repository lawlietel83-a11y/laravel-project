<?php

return [
    'midtrans' => [
        'server_key' => env('MIDTRANS_SERVER_KEY', ''),
        'client_key' => env('MIDTRANS_CLIENT_KEY', ''),
        'is_production' => env('MIDTRANS_IS_PRODUCTION', false),
        'sanitized' => true,
        'ssl_verify' => false,
    ],
    'rajaongkir' => [
        'api_key' => env('RAJAONGKIR_API_KEY', ''),
        'base_url' => 'https://api.rajaongkir.com/starter',
    ],
];
